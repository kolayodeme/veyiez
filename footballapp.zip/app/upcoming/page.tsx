import { UpcomingMatches } from "@/components/upcoming-matches"

export default function UpcomingPage() {
  return (
    <div className="container px-2 py-2 mx-auto">
      <h1 className="mb-3 text-lg font-bold">Upcoming Matches</h1>
      <UpcomingMatches />
    </div>
  )
}
