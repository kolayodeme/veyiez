import { LiveMatchTracker } from "@/components/live-match-tracker"
import { Suspense } from "react"
import { Skeleton } from "@/components/ui/skeleton"

export default function LivePage({ searchParams }: { searchParams: { match?: string } }) {
  return (
    <div className="container px-2 py-2 mx-auto">
      <h1 className="text-xl font-bold text-green-400 glow-text-green mb-4">Canlı Maç Takibi</h1>
      <Suspense fallback={<LiveMatchTrackerSkeleton />}>
        <LiveMatchTracker initialMatchId={searchParams.match} />
      </Suspense>
    </div>
  )
}

function LiveMatchTrackerSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-32 bg-slate-700" />
        <Skeleton className="h-8 w-32 bg-slate-700" />
      </div>
      <Skeleton className="h-1 w-full bg-slate-700" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Skeleton className="h-[500px] bg-slate-700 rounded-lg" />
        <div className="md:col-span-2 space-y-4">
          <Skeleton className="h-40 bg-slate-700 rounded-lg" />
          <Skeleton className="h-40 bg-slate-700 rounded-lg" />
          <Skeleton className="h-40 bg-slate-700 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
