import type React from "react"
import type { Metadata } from "next/dist/lib/metadata/types/metadata-interface"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { LanguageProvider } from "@/components/language-provider"
import { BottomNavigation } from "@/components/bottom-navigation"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Football App",
  description: "Real-time football match data, predictions, and statistics",
    generator: 'v0.dev'
}

// Update the layout to account for the smaller bottom navigation
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className + " bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 text-white"}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <LanguageProvider>
            <div className="flex flex-col min-h-screen">
              <main className="flex-1 pb-12">{children}</main>
              <BottomNavigation />
            </div>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
