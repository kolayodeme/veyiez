import { Suspense } from "react"
import { LanguageSwitcher } from "@/components/language-switcher"
import { ThemeToggle } from "@/components/theme-toggle"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import Link from "next/link"
import { Calendar, Clock, TrendingUp, Zap, Trophy, BarChart2, Timer } from "lucide-react"

export default function Home() {
  return (
    <div className="container px-2 py-2 mx-auto">
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-lg font-bold text-green-400 glow-text-green">Football App</h1>
        <div className="flex items-center space-x-1">
          <LanguageSwitcher />
          <ThemeToggle />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Sol Sütun - Hızlı Erişim */}
        <div className="space-y-4">
          <Card className="bg-gradient-to-br from-green-900/30 to-slate-900 border-green-700/30">
            <CardContent className="p-4">
              <h2 className="text-lg font-bold text-green-400 mb-3">Hızlı Erişim</h2>
              <div className="grid grid-cols-2 gap-2">
                <Link href="/live">
                  <Button
                    variant="outline"
                    className="w-full bg-red-900/20 border-red-700/30 hover:bg-red-900/30 text-white"
                  >
                    <Zap className="w-4 h-4 mr-2 text-red-400" />
                    Canlı Maçlar
                  </Button>
                </Link>
                <Link href="/upcoming">
                  <Button
                    variant="outline"
                    className="w-full bg-slate-800/50 border-slate-700/30 hover:bg-slate-800/70 text-white"
                  >
                    <Calendar className="w-4 h-4 mr-2 text-blue-400" />
                    Yaklaşan Maçlar
                  </Button>
                </Link>
                <Link href="/predictions">
                  <Button
                    variant="outline"
                    className="w-full bg-slate-800/50 border-slate-700/30 hover:bg-slate-800/70 text-white"
                  >
                    <TrendingUp className="w-4 h-4 mr-2 text-purple-400" />
                    Tahminler
                  </Button>
                </Link>
                <Link href="/statistics">
                  <Button
                    variant="outline"
                    className="w-full bg-slate-800/50 border-slate-700/30 hover:bg-slate-800/70 text-white"
                  >
                    <BarChart2 className="w-4 h-4 mr-2 text-yellow-400" />
                    İstatistikler
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-green-400">Günün Maçları</h2>
                <Badge variant="outline" className="bg-green-900/30 text-green-400 border-green-700/50">
                  <Clock className="w-3 h-3 mr-1" />
                  Bugün
                </Badge>
              </div>
              <Suspense fallback={<TodayMatchesSkeleton />}>
                <TodayMatches />
              </Suspense>
            </CardContent>
          </Card>
        </div>

        {/* Orta Sütun - Öne Çıkan Maç */}
        <div className="md:col-span-2">
          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-green-400">Öne Çıkan Maç</h2>
                <Badge variant="outline" className="bg-red-900/30 text-red-400 border-red-700/50 animate-pulse">
                  <Zap className="w-3 h-3 mr-1" />
                  Canlı
                </Badge>
              </div>
              <Suspense fallback={<FeaturedMatchSkeleton />}>
                <FeaturedMatch />
              </Suspense>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-lg font-bold text-green-400">Gol Krallığı</h2>
                  <Badge variant="outline" className="bg-yellow-900/30 text-yellow-400 border-yellow-700/50">
                    <Trophy className="w-3 h-3 mr-1" />
                    Top 5
                  </Badge>
                </div>
                <Suspense fallback={<TopScorersSkeleton />}>
                  <TopScorers />
                </Suspense>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-lg font-bold text-green-400">Günün Tahmini</h2>
                  <Badge variant="outline" className="bg-purple-900/30 text-purple-400 border-purple-700/50">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Özel
                  </Badge>
                </div>
                <Suspense fallback={<DailyPredictionSkeleton />}>
                  <DailyPrediction />
                </Suspense>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

// Bugünün maçları
function TodayMatches() {
  // Normalde API'den çekilecek, şimdilik örnek veri
  const matches = [
    {
      id: "1",
      league: "Premier League",
      homeTeam: "Arsenal",
      awayTeam: "Chelsea",
      time: "21:00",
      status: "upcoming",
    },
    {
      id: "2",
      league: "La Liga",
      homeTeam: "Barcelona",
      awayTeam: "Real Madrid",
      time: "22:00",
      status: "upcoming",
    },
    {
      id: "3",
      league: "Serie A",
      homeTeam: "Juventus",
      awayTeam: "Inter",
      time: "19:30",
      status: "live",
      score: "2-1",
    },
    {
      id: "4",
      league: "Bundesliga",
      homeTeam: "Bayern Munich",
      awayTeam: "Dortmund",
      time: "18:30",
      status: "finished",
      score: "3-2",
    },
  ]

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2">
        {matches.map((match) => (
          <Link
            href={match.status === "live" ? `/live?match=${match.id}` : `/upcoming?match=${match.id}`}
            key={match.id}
          >
            <div className="p-2 rounded-md bg-slate-800/50 hover:bg-slate-700/50 cursor-pointer">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-slate-400">{match.league}</span>
                {match.status === "live" ? (
                  <Badge variant="destructive" className="animate-pulse bg-red-600 text-[10px]">
                    <Timer className="w-2 h-2 mr-1" />
                    CANLI
                  </Badge>
                ) : match.status === "finished" ? (
                  <Badge variant="outline" className="text-[10px] bg-slate-700">
                    BİTTİ
                  </Badge>
                ) : (
                  <span className="text-xs text-slate-400">{match.time}</span>
                )}
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-white">{match.homeTeam}</span>
                {match.status === "upcoming" ? (
                  <span className="text-xs text-slate-400">vs</span>
                ) : (
                  <span className="text-sm font-bold text-green-400">{match.score}</span>
                )}
                <span className="text-sm text-white">{match.awayTeam}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </ScrollArea>
  )
}

// Öne çıkan maç
function FeaturedMatch() {
  // Normalde API'den çekilecek, şimdilik örnek veri
  const match = {
    id: "3",
    league: "Serie A",
    homeTeam: "Juventus",
    awayTeam: "Inter",
    homeScore: 2,
    awayScore: 1,
    minute: 67,
    homeImg: "/placeholder.svg?height=64&width=64",
    awayImg: "/placeholder.svg?height=64&width=64",
    events: [
      { type: "goal", team: "home", player: "Vlahovic", minute: 23 },
      { type: "goal", team: "away", player: "Martinez", minute: 45 },
      { type: "card", team: "away", player: "Barella", minute: 52, cardType: "yellow" },
      { type: "goal", team: "home", player: "Chiesa", minute: 58 },
    ],
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex flex-col items-center">
          <img
            src={match.homeImg || "/placeholder.svg"}
            alt={match.homeTeam}
            className="w-16 h-16 rounded-full bg-slate-700 mb-2"
            onError={(e) => {
              ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=64&width=64"
            }}
          />
          <span className="text-lg font-bold text-white">{match.homeTeam}</span>
        </div>

        <div className="flex flex-col items-center">
          <div className="flex items-center space-x-4 bg-slate-800 px-6 py-3 rounded-lg mb-2">
            <span className="text-3xl font-bold text-green-400">{match.homeScore}</span>
            <div className="flex flex-col items-center">
              <Badge variant="destructive" className="animate-pulse bg-red-600 mb-1">
                <Timer className="w-3 h-3 mr-1" />
                CANLI
              </Badge>
              <span className="text-sm text-slate-400">{match.minute}'</span>
            </div>
            <span className="text-3xl font-bold text-yellow-400">{match.awayScore}</span>
          </div>
          <span className="text-sm text-slate-400">{match.league}</span>
        </div>

        <div className="flex flex-col items-center">
          <img
            src={match.awayImg || "/placeholder.svg"}
            alt={match.awayTeam}
            className="w-16 h-16 rounded-full bg-slate-700 mb-2"
            onError={(e) => {
              ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=64&width=64"
            }}
          />
          <span className="text-lg font-bold text-white">{match.awayTeam}</span>
        </div>
      </div>

      <div className="bg-green-900/20 border border-green-700/30 rounded-lg p-4">
        <h3 className="text-lg font-bold text-green-400 mb-2">Maç Yorumu</h3>
        <p className="text-white">
          Juventus, Chiesa'nın 58. dakikada attığı golle 2-1 öne geçti. Inter'in Barella'sı 52. dakikada sarı kart gördü
          ve takımı baskı altında. Juventus bu skorla liderliğe yükselecek. İkinci yarıda Juventus daha etkili
          görünüyor.
        </p>
      </div>

      <div>
        <h3 className="text-base font-bold text-green-400 mb-2">Maç Olayları</h3>
        <div className="space-y-2">
          {match.events.map((event, index) => (
            <div
              key={index}
              className={`p-2 rounded-md ${
                event.team === "home"
                  ? "bg-green-900/20 border-l-4 border-green-500"
                  : "bg-yellow-900/20 border-l-4 border-yellow-500"
              }`}
            >
              <div className="flex items-center">
                <div className="w-8 text-center font-bold text-white">{event.minute}'</div>
                <div className="w-6 text-center">
                  {event.type === "goal" ? (
                    <span className="text-lg">⚽</span>
                  ) : event.cardType === "yellow" ? (
                    <span className="text-lg">🟨</span>
                  ) : (
                    <span className="text-lg">🟥</span>
                  )}
                </div>
                <div className="ml-2">
                  <span className="font-medium text-white">{event.player}</span>
                  <span className="text-xs text-slate-400 ml-1">
                    ({event.team === "home" ? match.homeTeam : match.awayTeam})
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Link href={`/live?match=${match.id}`}>
        <Button className="w-full bg-red-600 hover:bg-red-700">
          <Zap className="w-4 h-4 mr-2" />
          Canlı Takip Et
        </Button>
      </Link>
    </div>
  )
}

// Gol krallığı
function TopScorers() {
  // Normalde API'den çekilecek, şimdilik örnek veri
  const scorers = [
    { player: "Erling Haaland", team: "Man City", goals: 15, league: "Premier League" },
    { player: "Harry Kane", team: "Bayern Munich", goals: 13, league: "Bundesliga" },
    { player: "Kylian Mbappé", team: "Real Madrid", goals: 12, league: "La Liga" },
    { player: "Victor Osimhen", team: "Napoli", goals: 10, league: "Serie A" },
    { player: "Mohamed Salah", team: "Liverpool", goals: 9, league: "Premier League" },
  ]

  return (
    <div className="space-y-2">
      {scorers.map((scorer, index) => (
        <div key={index} className="flex items-center justify-between p-2 rounded-md bg-slate-800/50">
          <div className="flex items-center">
            <div className="w-6 h-6 rounded-full bg-yellow-900/50 flex items-center justify-center mr-2 text-xs font-bold">
              {index + 1}
            </div>
            <div>
              <div className="text-sm font-medium text-white">{scorer.player}</div>
              <div className="text-xs text-slate-400">{scorer.team}</div>
            </div>
          </div>
          <div className="flex items-center">
            <span className="text-sm font-bold text-yellow-400 mr-1">{scorer.goals}</span>
            <span className="text-xs text-slate-400">gol</span>
          </div>
        </div>
      ))}
    </div>
  )
}

// Günün tahmini
function DailyPrediction() {
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <div>
          <span className="text-sm text-white">Barcelona vs Real Madrid</span>
          <div className="text-xs text-slate-400">La Liga • 22:00</div>
        </div>
        <Badge className="bg-purple-600">Özel Tahmin</Badge>
      </div>

      <div className="p-3 rounded-md bg-purple-900/20 border border-purple-700/30">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-white">KG Var</span>
          <Badge variant="outline" className="bg-green-900/30 text-green-400">
            %78 Olasılık
          </Badge>
        </div>
        <p className="text-xs text-slate-300">
          Son 5 karşılaşmanın 4'ünde her iki takım da gol attı. Barcelona'nın son 7 maçının 6'sında KG Var gerçekleşti.
        </p>
      </div>

      <div className="p-3 rounded-md bg-purple-900/20 border border-purple-700/30">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-white">2.5 Üst</span>
          <Badge variant="outline" className="bg-green-900/30 text-green-400">
            %72 Olasılık
          </Badge>
        </div>
        <p className="text-xs text-slate-300">
          El Clasico'nun son 6 maçının 5'inde 3 veya daha fazla gol atıldı. Real Madrid'in son 8 deplasman maçının
          7'sinde 2.5 Üst gerçekleşti.
        </p>
      </div>

      <Link href="/predictions">
        <Button variant="outline" className="w-full">
          <TrendingUp className="w-4 h-4 mr-2" />
          Tüm Tahminleri Gör
        </Button>
      </Link>
    </div>
  )
}

// Yükleme iskeletleri
function TodayMatchesSkeleton() {
  return (
    <div className="space-y-2">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="p-2 rounded-md bg-slate-800/50">
          <div className="flex justify-between items-center mb-1">
            <Skeleton className="h-3 w-20 bg-slate-700" />
            <Skeleton className="h-3 w-10 bg-slate-700" />
          </div>
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-24 bg-slate-700" />
            <Skeleton className="h-4 w-8 bg-slate-700" />
            <Skeleton className="h-4 w-24 bg-slate-700" />
          </div>
        </div>
      ))}
    </div>
  )
}

function FeaturedMatchSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex flex-col items-center">
          <Skeleton className="w-16 h-16 rounded-full bg-slate-700 mb-2" />
          <Skeleton className="h-5 w-24 bg-slate-700" />
        </div>

        <div className="flex flex-col items-center">
          <div className="flex items-center space-x-4 bg-slate-800 px-6 py-3 rounded-lg mb-2">
            <Skeleton className="h-8 w-8 bg-slate-700" />
            <div className="flex flex-col items-center">
              <Skeleton className="h-4 w-16 bg-slate-700 mb-1" />
              <Skeleton className="h-3 w-8 bg-slate-700" />
            </div>
            <Skeleton className="h-8 w-8 bg-slate-700" />
          </div>
          <Skeleton className="h-3 w-20 bg-slate-700" />
        </div>

        <div className="flex flex-col items-center">
          <Skeleton className="w-16 h-16 rounded-full bg-slate-700 mb-2" />
          <Skeleton className="h-5 w-24 bg-slate-700" />
        </div>
      </div>

      <Skeleton className="h-32 w-full bg-slate-700 rounded-lg" />
      <Skeleton className="h-40 w-full bg-slate-700 rounded-lg" />
    </div>
  )
}

function TopScorersSkeleton() {
  return (
    <div className="space-y-2">
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="flex items-center justify-between p-2 rounded-md bg-slate-800/50">
          <div className="flex items-center">
            <Skeleton className="w-6 h-6 rounded-full bg-slate-700 mr-2" />
            <div>
              <Skeleton className="h-4 w-24 bg-slate-700 mb-1" />
              <Skeleton className="h-3 w-16 bg-slate-700" />
            </div>
          </div>
          <Skeleton className="h-4 w-10 bg-slate-700" />
        </div>
      ))}
    </div>
  )
}

function DailyPredictionSkeleton() {
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <div>
          <Skeleton className="h-4 w-32 bg-slate-700 mb-1" />
          <Skeleton className="h-3 w-24 bg-slate-700" />
        </div>
        <Skeleton className="h-5 w-20 bg-slate-700 rounded-full" />
      </div>

      <Skeleton className="h-24 w-full bg-slate-700 rounded-md" />
      <Skeleton className="h-24 w-full bg-slate-700 rounded-md" />
      <Skeleton className="h-9 w-full bg-slate-700 rounded-md" />
    </div>
  )
}
