"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { notificationService } from "@/lib/notification-service"
import { User, Heart, Settings, Trash2, Search, Plus, Save, LogOut, Loader2 } from "lucide-react"

interface UserSettings {
  username: string
  email: string
  notifications: boolean
  darkMode: boolean
  language: string
  favoriteTeams: FavoriteTeam[]
}

interface FavoriteTeam {
  id: string
  name: string
  logo?: string
}

export function UserProfile() {
  const [settings, setSettings] = useState<UserSettings>({
    username: "",
    email: "",
    notifications: false,
    darkMode: false,
    language: "tr",
    favoriteTeams: [],
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [searching, setSearching] = useState(false)
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  // Kullanıcı ayarlarını yükle
  useEffect(() => {
    const loadSettings = () => {
      const savedSettings = localStorage.getItem("user_settings")
      if (savedSettings) {
        try {
          const parsedSettings = JSON.parse(savedSettings)
          setSettings(parsedSettings)
        } catch (e) {
          console.error("Ayarlar yüklenirken hata:", e)
        }
      }
    }

    loadSettings()
  }, [])

  // Ayarları kaydet
  const saveSettings = () => {
    setSaving(true)

    setTimeout(() => {
      try {
        localStorage.setItem("user_settings", JSON.stringify(settings))

        // Bildirim ayarlarını güncelle
        if (notificationService) {
          notificationService.toggleNotifications(settings.notifications)
        }

        toast({
          title: "Ayarlar kaydedildi",
          description: "Kullanıcı ayarlarınız başarıyla güncellendi.",
          duration: 3000,
        })
      } catch (e) {
        console.error("Ayarlar kaydedilirken hata:", e)
        toast({
          title: "Hata",
          description: "Ayarlar kaydedilirken bir hata oluştu.",
          variant: "destructive",
          duration: 3000,
        })
      } finally {
        setSaving(false)
      }
    }, 500)
  }

  // Takım ara
  const searchTeams = (term: string) => {
    setSearchTerm(term)

    if (term.length < 2) {
      setSearchResults([])
      return
    }

    setSearching(true)

    // Örnek arama sonuçları (gerçek uygulamada API'den çekilecek)
    setTimeout(() => {
      const results = [
        { id: "1", name: "Barcelona", logo: "/placeholder.svg?height=40&width=40&text=FCB" },
        { id: "2", name: "Real Madrid", logo: "/placeholder.svg?height=40&width=40&text=RM" },
        { id: "3", name: "Bayern Munich", logo: "/placeholder.svg?height=40&width=40&text=BM" },
        { id: "4", name: "Manchester United", logo: "/placeholder.svg?height=40&width=40&text=MU" },
        { id: "5", name: "Liverpool", logo: "/placeholder.svg?height=40&width=40&text=LIV" },
        { id: "6", name: "Juventus", logo: "/placeholder.svg?height=40&width=40&text=JUV" },
        { id: "7", name: "Paris Saint-Germain", logo: "/placeholder.svg?height=40&width=40&text=PSG" },
        { id: "8", name: "Manchester City", logo: "/placeholder.svg?height=40&width=40&text=MC" },
        { id: "9", name: "Chelsea", logo: "/placeholder.svg?height=40&width=40&text=CHE" },
        { id: "10", name: "Arsenal", logo: "/placeholder.svg?height=40&width=40&text=ARS" },
      ].filter((team) => team.name.toLowerCase().includes(term.toLowerCase()))

      setSearchResults(results)
      setSearching(false)
    }, 500)
  }

  // Favori takım ekle
  const addFavoriteTeam = (team: FavoriteTeam) => {
    if (settings.favoriteTeams.some((t) => t.id === team.id)) {
      toast({
        title: "Takım zaten favorilerde",
        description: `${team.name} zaten favori takımlarınızda bulunuyor.`,
        duration: 3000,
      })
      return
    }

    setSettings({
      ...settings,
      favoriteTeams: [...settings.favoriteTeams, team],
    })

    toast({
      title: "Takım eklendi",
      description: `${team.name} favori takımlarınıza eklendi.`,
      duration: 3000,
    })
  }

  // Favori takım kaldır
  const removeFavoriteTeam = (teamId: string) => {
    setSettings({
      ...settings,
      favoriteTeams: settings.favoriteTeams.filter((team) => team.id !== teamId),
    })

    toast({
      title: "Takım kaldırıldı",
      description: "Takım favori listesinden kaldırıldı.",
      duration: 3000,
    })
  }

  // Bildirim izni iste
  const requestNotificationPermission = async () => {
    if (notificationService) {
      const granted = await notificationService.requestPermission()

      if (granted) {
        setSettings({
          ...settings,
          notifications: true,
        })

        toast({
          title: "Bildirimler açıldı",
          description: "Artık maç olayları için bildirim alacaksınız.",
          duration: 3000,
        })
      } else {
        toast({
          title: "Bildirim izni reddedildi",
          description: "Bildirim almak için tarayıcı izinlerini kontrol edin.",
          variant: "destructive",
          duration: 3000,
        })
      }
    }
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src="/placeholder.svg?height=48&width=48&text=U" alt="User" />
            <AvatarFallback>U</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle>Kullanıcı Profili</CardTitle>
            <CardDescription>Hesap ayarlarınızı ve favori takımlarınızı yönetin</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="profile">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="profile">
              <User className="w-4 h-4 mr-2" />
              Profil
            </TabsTrigger>
            <TabsTrigger value="favorites">
              <Heart className="w-4 h-4 mr-2" />
              Favoriler
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Ayarlar
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="username">Kullanıcı Adı</Label>
                <Input
                  id="username"
                  value={settings.username}
                  onChange={(e) => setSettings({ ...settings, username: e.target.value })}
                  placeholder="Kullanıcı adınızı girin"
                />
              </div>
              <div>
                <Label htmlFor="email">E-posta</Label>
                <Input
                  id="email"
                  type="email"
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  placeholder="E-posta adresinizi girin"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline">
                <LogOut className="w-4 h-4 mr-2" />
                Çıkış Yap
              </Button>
              <Button onClick={saveSettings} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                Kaydet
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="favorites" className="space-y-4">
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Takım ara..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => searchTeams(e.target.value)}
                />
              </div>

              {searchTerm.length > 1 && (
                <Card className="mt-2">
                  <CardContent className="p-2">
                    {searching ? (
                      <div className="flex justify-center py-4">
                        <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      </div>
                    ) : searchResults.length > 0 ? (
                      <ScrollArea className="h-48">
                        <div className="space-y-2">
                          {searchResults.map((team) => (
                            <div
                              key={team.id}
                              className="flex items-center justify-between p-2 hover:bg-secondary rounded-md"
                            >
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                                  <img
                                    src={team.logo || "/placeholder.svg"}
                                    alt={team.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <span>{team.name}</span>
                              </div>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => addFavoriteTeam(team)}
                                className="h-8 w-8 p-0"
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    ) : (
                      <p className="text-center py-4 text-sm text-muted-foreground">Sonuç bulunamadı</p>
                    )}
                  </CardContent>
                </Card>
              )}

              <div>
                <h3 className="text-lg font-medium mb-2">Favori Takımlarım</h3>
                {settings.favoriteTeams.length > 0 ? (
                  <div className="space-y-2">
                    {settings.favoriteTeams.map((team) => (
                      <div
                        key={team.id}
                        className="flex items-center justify-between p-2 hover:bg-secondary rounded-md"
                      >
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                            <img
                              src={team.logo || "/placeholder.svg"}
                              alt={team.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <span>{team.name}</span>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeFavoriteTeam(team.id)}
                          className="h-8 w-8 p-0 text-destructive hover:text-destructive/90"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center py-4 text-sm text-muted-foreground">
                    Henüz favori takım eklemediniz. Yukarıdan takım arayarak favorilerinize ekleyebilirsiniz.
                  </p>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="notifications">Bildirimler</Label>
                  <p className="text-sm text-muted-foreground">Maç olayları için bildirim almak istiyorsanız açın</p>
                </div>
                <Switch
                  id="notifications"
                  checked={settings.notifications}
                  onCheckedChange={(checked) => {
                    if (checked && notificationService && notificationService.getPermission() !== "granted") {
                      requestNotificationPermission()
                    } else {
                      setSettings({ ...settings, notifications: checked })
                    }
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="darkMode">Karanlık Mod</Label>
                  <p className="text-sm text-muted-foreground">Uygulamayı karanlık modda kullanmak için açın</p>
                </div>
                <Switch
                  id="darkMode"
                  checked={settings.darkMode}
                  onCheckedChange={(checked) => setSettings({ ...settings, darkMode: checked })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="language">Dil</Label>
                <select
                  id="language"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={settings.language}
                  onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                >
                  <option value="tr">Türkçe</option>
                  <option value="en">English</option>
                  <option value="de">Deutsch</option>
                  <option value="fr">Français</option>
                  <option value="es">Español</option>
                </select>
              </div>

              <div className="flex justify-end">
                <Button onClick={saveSettings} disabled={saving}>
                  {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                  Ayarları Kaydet
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
