"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useTranslation } from "./language-provider"
import { Loader2, Trophy } from "lucide-react"

interface TeamStanding {
  position: number
  team_name: string
  matches_played: number
  won: number
  draw: number
  lost: number
  goals_for: number
  goals_against: number
  points: number
  form: string
}

interface MatchStandingsProps {
  leagueName: string
  homeTeam: string
  awayTeam: string
}

export function MatchStandings({ leagueName, homeTeam, awayTeam }: MatchStandingsProps) {
  const { t } = useTranslation()
  const [loading, setLoading] = useState(true)
  const [standings, setStandings] = useState<TeamStanding[]>([])

  useEffect(() => {
    // In a real app, we would fetch standings from the API
    // For now, generate mock data
    const generateMockStandings = () => {
      const teams = [
        "Fenerbahçe",
        "Galatasaray",
        "Beşiktaş",
        "Trabzonspor",
        "Başakşehir",
        "Adana Demirspor",
        "Konyaspor",
        "Antalyaspor",
        "Kasımpaşa",
        "Sivasspor",
        "Alanyaspor",
        "Kayserispor",
        "Hatayspor",
        "Gaziantep FK",
        "Ankaragücü",
        "Karagümrük",
        "Ümraniyespor",
        "Giresunspor",
      ]

      // Make sure home and away teams are included
      if (!teams.includes(homeTeam)) teams[Math.floor(Math.random() * teams.length)] = homeTeam
      if (!teams.includes(awayTeam)) teams[Math.floor(Math.random() * teams.length)] = awayTeam

      const formOptions = ["W", "D", "L"]

      return teams
        .map((team, index) => {
          const matches = 34 - Math.floor(Math.random() * 10)
          const won = Math.floor(Math.random() * matches)
          const draw = Math.floor(Math.random() * (matches - won))
          const lost = matches - won - draw
          const goalsFor = won * 2 + draw + Math.floor(Math.random() * 20)
          const goalsAgainst = lost * 2 + draw + Math.floor(Math.random() * 15)
          const points = won * 3 + draw

          // Generate last 5 matches form
          const form = Array(5)
            .fill(0)
            .map(() => formOptions[Math.floor(Math.random() * formOptions.length)])
            .join("")

          return {
            position: index + 1,
            team_name: team,
            matches_played: matches,
            won,
            draw,
            lost,
            goals_for: goalsFor,
            goals_against: goalsAgainst,
            points,
            form,
          }
        })
        .sort((a, b) => b.points - a.points || b.goals_for - b.goals_against - (a.goals_for - a.goals_against))
        .map((team, index) => ({ ...team, position: index + 1 }))
    }

    setLoading(true)
    // Simulate API delay
    setTimeout(() => {
      const mockStandings = generateMockStandings()
      setStandings(mockStandings)
      setLoading(false)
    }, 1000)
  }, [leagueName, homeTeam, awayTeam])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <Loader2 className="w-6 h-6 animate-spin text-green-500 mb-2" />
        <p className="text-xs text-green-400">Puan durumu yükleniyor...</p>
      </div>
    )
  }

  const homeTeamStanding = standings.find((team) => team.team_name === homeTeam)
  const awayTeamStanding = standings.find((team) => team.team_name === awayTeam)

  return (
    <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=400')] opacity-5"></div>
      <CardHeader className="p-3 relative z-10">
        <CardTitle className="text-base text-white flex items-center">
          <Trophy className="w-4 h-4 mr-2 text-yellow-400" />
          <span className="text-green-400">{leagueName}</span>
          <span className="text-xs text-slate-400 ml-2">Puan Durumu</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 relative z-10">
        <Tabs defaultValue="full">
          <TabsList className="w-full bg-green-900/30 rounded-none">
            <TabsTrigger
              value="full"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Tam Tablo
            </TabsTrigger>
            <TabsTrigger
              value="teams"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Takımlar
            </TabsTrigger>
          </TabsList>

          <TabsContent value="full" className="p-3 space-y-2">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-green-700/30">
                    <th className="p-1 text-left text-green-400">#</th>
                    <th className="p-1 text-left text-green-400">Takım</th>
                    <th className="p-1 text-center text-green-400">O</th>
                    <th className="p-1 text-center text-green-400">G</th>
                    <th className="p-1 text-center text-green-400">B</th>
                    <th className="p-1 text-center text-green-400">M</th>
                    <th className="p-1 text-center text-green-400">A</th>
                    <th className="p-1 text-center text-green-400">Y</th>
                    <th className="p-1 text-center text-green-400">P</th>
                  </tr>
                </thead>
                <tbody>
                  {standings.map((team) => (
                    <tr
                      key={team.position}
                      className={`border-b border-slate-700/30 ${
                        team.team_name === homeTeam || team.team_name === awayTeam ? "bg-green-900/20" : ""
                      }`}
                    >
                      <td className="p-1 text-left">
                        {team.position <= 3 ? (
                          <span
                            className={`
                            inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold
                            ${
                              team.position === 1
                                ? "bg-yellow-900/50 text-yellow-400"
                                : team.position === 2
                                  ? "bg-slate-400/20 text-slate-300"
                                  : "bg-amber-800/30 text-amber-400"
                            }
                          `}
                          >
                            {team.position}
                          </span>
                        ) : (
                          <span className="text-slate-400">{team.position}</span>
                        )}
                      </td>
                      <td
                        className={`p-1 text-left font-medium ${
                          team.team_name === homeTeam
                            ? "text-green-400"
                            : team.team_name === awayTeam
                              ? "text-yellow-400"
                              : "text-white"
                        }`}
                      >
                        {team.team_name}
                      </td>
                      <td className="p-1 text-center text-slate-300">{team.matches_played}</td>
                      <td className="p-1 text-center text-green-400">{team.won}</td>
                      <td className="p-1 text-center text-yellow-400">{team.draw}</td>
                      <td className="p-1 text-center text-red-400">{team.lost}</td>
                      <td className="p-1 text-center text-slate-300">{team.goals_for}</td>
                      <td className="p-1 text-center text-slate-300">{team.goals_against}</td>
                      <td className="p-1 text-center font-bold text-white">{team.points}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="teams" className="p-3 space-y-3">
            {homeTeamStanding && (
              <div className="p-2 bg-green-900/20 border border-green-700/30 rounded-md">
                <h4 className="text-xs font-medium text-green-400 mb-1">{homeTeam}</h4>
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Sıra:</span>
                    <span className="ml-1 font-bold text-white">{homeTeamStanding.position}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Puan:</span>
                    <span className="ml-1 font-bold text-white">{homeTeamStanding.points}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">O/G/B/M:</span>
                    <span className="ml-1 text-white">
                      {homeTeamStanding.matches_played}/{homeTeamStanding.won}/{homeTeamStanding.draw}/
                      {homeTeamStanding.lost}
                    </span>
                  </div>
                </div>
                <div className="mt-1 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Averaj:</span>
                    <span className="ml-1 text-white">
                      {homeTeamStanding.goals_for}-{homeTeamStanding.goals_against}(
                      {homeTeamStanding.goals_for - homeTeamStanding.goals_against > 0 ? "+" : ""}
                      {homeTeamStanding.goals_for - homeTeamStanding.goals_against})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Form:</span>
                    <span className="ml-1">
                      {homeTeamStanding.form.split("").map((result, i) => (
                        <span
                          key={i}
                          className={`inline-block w-4 h-4 text-[10px] text-center leading-4 rounded-sm ml-0.5 
                            ${
                              result === "W"
                                ? "bg-green-900/50 text-green-400"
                                : result === "D"
                                  ? "bg-yellow-900/50 text-yellow-400"
                                  : "bg-red-900/50 text-red-400"
                            }`}
                        >
                          {result === "W" ? "G" : result === "D" ? "B" : "M"}
                        </span>
                      ))}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {awayTeamStanding && (
              <div className="p-2 bg-yellow-900/20 border border-yellow-700/30 rounded-md">
                <h4 className="text-xs font-medium text-yellow-400 mb-1">{awayTeam}</h4>
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Sıra:</span>
                    <span className="ml-1 font-bold text-white">{awayTeamStanding.position}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Puan:</span>
                    <span className="ml-1 font-bold text-white">{awayTeamStanding.points}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">O/G/B/M:</span>
                    <span className="ml-1 text-white">
                      {awayTeamStanding.matches_played}/{awayTeamStanding.won}/{awayTeamStanding.draw}/
                      {awayTeamStanding.lost}
                    </span>
                  </div>
                </div>
                <div className="mt-1 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Averaj:</span>
                    <span className="ml-1 text-white">
                      {awayTeamStanding.goals_for}-{awayTeamStanding.goals_against}(
                      {awayTeamStanding.goals_for - awayTeamStanding.goals_against > 0 ? "+" : ""}
                      {awayTeamStanding.goals_for - awayTeamStanding.goals_against})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Form:</span>
                    <span className="ml-1">
                      {awayTeamStanding.form.split("").map((result, i) => (
                        <span
                          key={i}
                          className={`inline-block w-4 h-4 text-[10px] text-center leading-4 rounded-sm ml-0.5 
                            ${
                              result === "W"
                                ? "bg-green-900/50 text-green-400"
                                : result === "D"
                                  ? "bg-yellow-900/50 text-yellow-400"
                                  : "bg-red-900/50 text-red-400"
                            }`}
                        >
                          {result === "W" ? "G" : result === "D" ? "B" : "M"}
                        </span>
                      ))}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
