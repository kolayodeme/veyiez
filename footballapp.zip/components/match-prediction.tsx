"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useTranslation } from "./language-provider"
import { useEffect, useState } from "react"
import { AlertCircle, Sparkles, Zap, Loader2, RefreshCw } from "lucide-react"
import { getTeamForm } from "@/lib/football-api"
import { Button } from "@/components/ui/button"

interface MatchPredictionProps {
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  matchStatus: string
  homeTeamId?: string
  awayTeamId?: string
  isLive?: boolean
}

export function MatchPrediction({
  homeTeam,
  awayTeam,
  homeScore,
  awayScore,
  matchStatus,
  homeTeamId,
  awayTeamId,
  isLive = false,
}: MatchPredictionProps) {
  const { t } = useTranslation()
  const [predictionComment, setPredictionComment] = useState("")
  const [loading, setLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [homeForm, setHomeForm] = useState<number>(50)
  const [awayForm, setAwayForm] = useState<number>(50)

  // Calculate prediction probabilities based on current score and match status
  const totalGoals = homeScore + awayScore
  const scoreDiff = Math.abs(homeScore - awayScore)
  const isFinished = matchStatus === "FT"
  const isFirstHalf = matchStatus === "1H" || (Number.parseInt(matchStatus) || 0) < 45
  const isSecondHalf = !isFirstHalf && isLive
  const timeRemaining = isFirstHalf ? 70 : isSecondHalf ? 45 - (Number.parseInt(matchStatus) || 0) : 0

  // Enhanced home win probability algorithm
  const homeWinProb = calculateWinProbability("home")

  // Enhanced draw probability algorithm
  const drawProb = calculateDrawProbability()

  // Enhanced away win probability algorithm
  const awayWinProb = calculateWinProbability("away")

  // Over/Under probabilities with enhanced algorithm
  const over1_5Prob = calculateOverUnderProbability(1.5)
  const over2_5Prob = calculateOverUnderProbability(2.5)
  const over3_5Prob = calculateOverUnderProbability(3.5)

  // BTTS probability with enhanced algorithm
  const bttsProb = calculateBttsProb()

  // Fetch team form data if team IDs are provided
  useEffect(() => {
    const fetchTeamForm = async () => {
      if (!homeTeamId || !awayTeamId) return

      setLoading(true)
      setError(null)

      try {
        // Fetch form data for both teams
        const [homeFormData, awayFormData] = await Promise.all([getTeamForm(homeTeamId), getTeamForm(awayTeamId)])

        // Calculate form based on results
        if (Array.isArray(homeFormData) && homeFormData.length > 0) {
          const homeFormValue = calculateTeamFormValue(homeFormData)
          setHomeForm(homeFormValue)
        }

        if (Array.isArray(awayFormData) && awayFormData.length > 0) {
          const awayFormValue = calculateTeamFormValue(awayFormData)
          setAwayForm(awayFormValue)
        }
      } catch (err) {
        console.error("Error fetching team form:", err)
        setError("Takım form verileri yüklenirken bir hata oluştu.")
      } finally {
        setLoading(false)
      }
    }

    fetchTeamForm()
  }, [homeTeamId, awayTeamId])

  // Helper function to calculate team form value (0-100)
  const calculateTeamFormValue = (formData: string[]): number => {
    if (!Array.isArray(formData) || formData.length === 0) return 50

    let points = 0
    const maxPoints = formData.length * 3

    formData.forEach((result) => {
      if (result === "W") points += 3
      else if (result === "D") points += 1
    })

    return Math.round((points / maxPoints) * 100)
  }

  // Refresh prediction data
  const handleRefresh = async () => {
    if (!homeTeamId || !awayTeamId || refreshing) return

    setRefreshing(true)
    setError(null)

    try {
      // Fetch form data for both teams
      const [homeFormData, awayFormData] = await Promise.all([getTeamForm(homeTeamId), getTeamForm(awayTeamId)])

      // Calculate form based on results
      if (Array.isArray(homeFormData) && homeFormData.length > 0) {
        const homeFormValue = calculateTeamFormValue(homeFormData)
        setHomeForm(homeFormValue)
      }

      if (Array.isArray(awayFormData) && awayFormData.length > 0) {
        const awayFormValue = calculateTeamFormValue(awayFormData)
        setAwayForm(awayFormValue)
      }
    } catch (err) {
      console.error("Error refreshing team form:", err)
      setError("Takım form verileri güncellenirken bir hata oluştu.")
    } finally {
      setRefreshing(false)
    }
  }

  function calculateWinProbability(team: "home" | "away") {
    if (isFinished) {
      // Match is finished, return 100% for the winner, 0 for loser, 50% each for draw
      if (homeScore === awayScore) {
        return 0
      }
      if (team === "home") {
        return homeScore > awayScore ? 100 : 0
      } else {
        return awayScore > homeScore ? 100 : 0
      }
    }

    const leadingTeam = homeScore > awayScore ? "home" : awayScore > homeScore ? "away" : "draw"

    // Base probability with team form consideration
    const baseProb =
      team === "home"
        ? 45 + (homeForm - 50) * 0.2 // Adjust based on home form
        : 40 + (awayForm - 50) * 0.2 // Adjust based on away form

    // Calculate advantage based on current score
    let scoreAdvantage = 0
    if (leadingTeam === team) {
      // Team is leading
      scoreAdvantage = scoreDiff * 15
    } else if (leadingTeam !== "draw") {
      // Team is trailing
      scoreAdvantage = -scoreDiff * 10
    }

    // Time factor - probability increases for leading team as time passes
    const matchMinute = Number.parseInt(matchStatus) || 0
    const timeRemainingFactor = (90 - matchMinute) / 90
    const timeFactor = leadingTeam === team ? (1 - timeRemainingFactor) * 20 : timeRemainingFactor * 10

    let finalProb = baseProb + scoreAdvantage + timeFactor

    // Momentum adjustment (if there's been a recent goal)
    if (leadingTeam === team && scoreDiff === 1) {
      finalProb += 5 // Team has momentum from scoring
    }

    // Ensure probability is between 0 and 100
    return Math.max(0, Math.min(100, finalProb))
  }

  function calculateDrawProbability() {
    if (isFinished) {
      // Match is finished, 100% if it's a draw, 0 otherwise
      return homeScore === awayScore ? 100 : 0
    }

    // Base draw probability
    let baseProb = 25

    // If scores are level, draw is more likely
    if (homeScore === awayScore) {
      baseProb += 20

      // As match progresses with level scores, draw becomes more likely
      const matchMinute = Number.parseInt(matchStatus) || 0
      const timeProgress = matchMinute / 90
      baseProb += timeProgress * 20
    } else {
      // If there's a goal difference, draw is less likely
      baseProb -= scoreDiff * 10

      // But as time runs out, comebacks are less likely
      const matchMinute = Number.parseInt(matchStatus) || 0
      const timeRemaining = (90 - matchMinute) / 90
      if (scoreDiff === 1) {
        // One goal difference can still lead to equalizer
        baseProb += timeRemaining * 15
      } else {
        // Larger differences less likely to be equalized
        baseProb += timeRemaining * 5
      }
    }

    // Ensure probability is between 0 and 100
    return Math.max(0, Math.min(100, baseProb))
  }

  function calculateOverUnderProbability(line: number) {
    if (isFinished) {
      // Match is finished, return 100% if over the line, 0 if under
      return totalGoals > line ? 100 : 0
    }

    // Base probability
    let baseProb = 50

    // If already over the line, 100%
    if (totalGoals > line) {
      return 100
    }

    // Goals needed to go over
    const goalsNeeded = line + 0.5 - totalGoals

    // Average goals per minute based on current rate
    const matchMinute = Math.max(1, Number.parseInt(matchStatus) || 1)
    const currentGoalsPerMinute = totalGoals / matchMinute

    // Expected additional goals
    const remainingMinutes = 90 - matchMinute
    const expectedAdditionalGoals = currentGoalsPerMinute * remainingMinutes

    // If current pace exceeds goals needed, increase probability
    if (expectedAdditionalGoals >= goalsNeeded) {
      baseProb = 50 + (expectedAdditionalGoals / goalsNeeded) * 25
    } else {
      baseProb = 50 - ((goalsNeeded - expectedAdditionalGoals) / goalsNeeded) * 25
    }

    // Game state adjustments
    if (scoreDiff <= 1) {
      // Close games tend to have more goals as teams push
      baseProb += 10
    }

    // Time adjustments
    if (matchMinute > 75 && goalsNeeded > 1) {
      // Hard to score multiple goals in little time
      baseProb -= 20
    } else if (matchMinute > 60 && totalGoals === 0) {
      // 0-0 after 60 mins often stays low scoring
      baseProb -= 15
    }

    // Ensure probability is between 0 and 100
    return Math.max(0, Math.min(100, baseProb))
  }

  function calculateBttsProb() {
    if (isFinished) {
      // Match is finished, return 100% if both teams scored, 0 otherwise
      return homeScore > 0 && awayScore > 0 ? 100 : 0
    }

    // If both teams have already scored, 100%
    if (homeScore > 0 && awayScore > 0) {
      return 100
    }

    // Base probability
    let baseProb = 60 // BTTS happens in majority of games

    // If one team hasn't scored yet
    if (homeScore === 0 || awayScore === 0) {
      // Reduce probability based on time elapsed
      const timeElapsed = Number.parseInt(matchStatus) || 0
      baseProb -= (timeElapsed / 90) * 40

      // If there's a big score difference, trailing team less likely to score
      if (scoreDiff >= 2) {
        baseProb -= 15
      }
    }

    // If neither team has scored, probability decreases more rapidly with time
    if (homeScore === 0 && awayScore === 0) {
      const timeElapsed = Number.parseInt(matchStatus) || 0
      baseProb -= (timeElapsed / 90) * 50
    }

    // Ensure probability is between 0 and 100
    return Math.max(0, Math.min(100, baseProb))
  }

  // Generate prediction comment
  useEffect(() => {
    if (isFinished) {
      if (homeScore === awayScore) {
        setPredictionComment(
          `Maç ${homeScore}-${awayScore} berabere sonuçlandı. İki takım da birbirine denk bir performans sergiledi.`,
        )
      } else if (homeScore > awayScore) {
        setPredictionComment(
          `${homeTeam}, ${awayTeam}'i ${homeScore}-${awayScore} mağlup etti. ${scoreDiff > 1 ? "Net bir galibiyet" : "Zorlu bir maçta kazanan taraf oldu"}.`,
        )
      } else {
        setPredictionComment(
          `${awayTeam}, deplasmanda ${homeTeam}'i ${awayScore}-${homeScore} mağlup etmeyi başardı. ${scoreDiff > 1 ? "Etkileyici bir deplasman galibiyeti" : "Kritik puanları aldı"}.`,
        )
      }
      return
    }

    const matchMinute = Number.parseInt(matchStatus) || 0
    let comment = ""

    if (homeScore > awayScore && homeScore - awayScore >= 2) {
      comment = `${matchMinute}. dakikada ${homeTeam} sahada ${homeScore}-${awayScore} üstün durumda. ${awayTeam} skoru yakalamakta zorlanıyor.`
    } else if (awayScore > homeScore && awayScore - homeScore >= 2) {
      comment = `${matchMinute}. dakikada ${awayTeam} deplasmanda ${awayScore}-${homeScore} öne geçti. ${homeTeam}'in daha fazla risk alması gerekiyor.`
    } else if (homeScore === awayScore && totalGoals >= 2) {
      comment = `${matchMinute}. dakikada skor ${homeScore}-${awayScore}. İki takım da güçlü performans sergiliyor, sonuç belirsiz.`
    } else if (totalGoals >= 4) {
      comment = `${matchMinute}. dakikada yüksek skorlu bir maç izliyoruz: ${homeScore}-${awayScore}. 3.5 Üst bahsi kazandı.`
    } else if (totalGoals === 0 && matchMinute > 60) {
      comment = `${matchMinute}. dakikada henüz gol yok. Savunmaların öne çıktığı bir maç, 2.5 Alt olasılığı yüksek.`
    } else if (homeScore > 0 && awayScore > 0) {
      comment = `${matchMinute}. dakikada her iki takım da gol buldu (${homeScore}-${awayScore}), KG Var bahsi kazandı!`
    } else if (matchStatus === "1H" && totalGoals >= 2) {
      comment = `İlk yarıda hızlı tempolu bir maç izliyoruz, şu ana kadar ${totalGoals} gol atıldı. Daha fazla gol beklenebilir.`
    } else if (matchMinute > 75 && scoreDiff === 0) {
      comment = `Maçın son dakikalarında skor ${homeScore}-${awayScore}. Beraberlik bozulabilir, dikkat!`
    } else if (matchMinute > 75 && scoreDiff === 1) {
      const leadingTeam = homeScore > awayScore ? homeTeam : awayTeam
      const trailingTeam = homeScore > awayScore ? awayTeam : homeTeam
      comment = `${matchMinute}. dakikada ${leadingTeam} ${scoreDiff} farkla önde. ${trailingTeam} son dakikalarda eşitlik için baskı yapıyor.`
    } else {
      comment = `${matchMinute}. dakikada skor ${homeScore}-${awayScore}. Maç devam ediyor, tahminler canlı olarak güncelleniyor.`
    }

    setPredictionComment(comment)
  }, [homeScore, awayScore, homeTeam, awayTeam, matchStatus, isFinished, totalGoals, scoreDiff])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <Loader2 className="w-6 h-6 animate-spin text-green-500 mb-2" />
        <p className="text-xs text-green-400">Tahmin verileri yükleniyor...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center p-4 bg-red-900/20 rounded-md border border-red-700/30">
        <AlertCircle className="w-5 h-5 text-red-400 mx-auto mb-2" />
        <p className="text-sm text-red-400 mb-2">{error}</p>
        <Button variant="outline" size="sm" onClick={handleRefresh} className="border-red-700/50 text-red-400">
          Yeniden Dene
        </Button>
      </div>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=400')] opacity-5"></div>
      <CardHeader className="p-3 relative z-10">
        <CardTitle className="text-base text-white flex items-center justify-between">
          <div className="flex items-center">
            <Sparkles className="w-4 h-4 mr-2 text-yellow-400" />
            <span className="text-green-400">{t("matchPredictions")}</span>
            {isLive && (
              <Badge className="ml-2 text-[10px] animate-pulse bg-red-600 text-white">
                <Zap className="w-2 h-2 mr-1" />
                CANLI
              </Badge>
            )}
          </div>
          {isLive && (
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-slate-400 hover:text-white"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`h-3 w-3 ${refreshing ? "animate-spin" : ""}`} />
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 space-y-4 relative z-10">
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("matchWinner")}</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-green-400">{homeTeam}</span>
              <span>{Math.round(homeWinProb)}%</span>
            </div>
            <Progress value={homeWinProb} className="h-1.5 bg-slate-700" indicatorClassName="bg-green-500 glow-green" />

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>{t("draw")}</span>
              <span>{Math.round(drawProb)}%</span>
            </div>
            <Progress value={drawProb} className="h-1.5 bg-slate-700" indicatorClassName="bg-yellow-500 glow-yellow" />

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-yellow-400">{awayTeam}</span>
              <span>{Math.round(awayWinProb)}%</span>
            </div>
            <Progress
              value={awayWinProb}
              className="h-1.5 bg-slate-700"
              indicatorClassName="bg-yellow-500 glow-yellow"
            />
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("overUnder")}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>O 1.5</span>
                <span>{Math.round(over1_5Prob)}%</span>
              </div>
              <Progress
                value={over1_5Prob}
                className="h-1.5 bg-slate-700"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>U 1.5</span>
                <span>{Math.round(100 - over1_5Prob)}%</span>
              </div>
              <Progress
                value={100 - over1_5Prob}
                className="h-1.5 bg-slate-700"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>O 2.5</span>
                <span>{Math.round(over2_5Prob)}%</span>
              </div>
              <Progress
                value={over2_5Prob}
                className="h-1.5 bg-slate-700"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>U 2.5</span>
                <span>{Math.round(100 - over2_5Prob)}%</span>
              </div>
              <Progress
                value={100 - over2_5Prob}
                className="h-1.5 bg-slate-700"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("btts")}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>{t("yes")}</span>
                <span>{Math.round(bttsProb)}%</span>
              </div>
              <Progress value={bttsProb} className="h-1.5 bg-slate-700" indicatorClassName="bg-green-500 glow-green" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>{t("no")}</span>
                <span>{Math.round(100 - bttsProb)}%</span>
              </div>
              <Progress
                value={100 - bttsProb}
                className="h-1.5 bg-slate-700"
                indicatorClassName="bg-green-500 glow-green"
              />
            </div>
          </div>
        </div>

        {predictionComment && (
          <div className="p-2 mt-3 rounded-lg bg-green-900/20 border border-green-700/30">
            <h3 className="mb-1 text-xs font-medium text-green-400 flex items-center">
              <AlertCircle className="w-3 h-3 mr-1" />
              {t("predictionComment")}
            </h3>
            <p className="text-xs text-slate-300">{predictionComment}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
