import type React from "react"
import { cn } from "@/lib/utils"

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("bg-slate-700 animate-pulse rounded", className)} {...props} />
}

export { Skeleton }
