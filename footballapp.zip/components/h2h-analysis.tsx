"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getHeadToHead } from "@/lib/football-api"
import { RefreshCw, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"

interface H2HAnalysisProps {
  firstTeamId: string
  secondTeamId: string
  firstTeamName: string
  secondTeamName: string
}

interface Match {
  id: number | string
  homeTeam: { id: number | string; name: string }
  awayTeam: { id: number | string; name: string }
  score: { fullTime: { home: number; away: number } }
  utcDate: string
  status: string
}

interface H2HStats {
  team1Wins: number
  team2Wins: number
  draws: number
  team1Goals: number
  team2Goals: number
  totalMatches: number
}

export function H2HAnalysis({ firstTeamId, secondTeamId, firstTeamName, secondTeamName }: H2HAnalysisProps) {
  const [matches, setMatches] = useState<Match[]>([])
  const [stats, setStats] = useState<H2HStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchH2H = async (showLoading = true) => {
    if (showLoading) setLoading(true)
    else setRefreshing(true)

    setError(null)

    try {
      // H2H verilerini çek
      const data = await getHeadToHead(firstTeamId, secondTeamId)

      if (data && data.matches && data.matches.length > 0) {
        setMatches(data.matches)
        calculateStats(data.matches)
      } else {
        setError("H2H verisi bulunamadı.")
      }
    } catch (err) {
      console.error("H2H verisi çekilirken hata:", err)
      setError("H2H verisi yüklenirken bir hata oluştu.")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const calculateStats = (matches: Match[]) => {
    let team1Wins = 0
    let team2Wins = 0
    let draws = 0
    let team1Goals = 0
    let team2Goals = 0

    matches.forEach((match) => {
      const isTeam1Home = match.homeTeam.id.toString() === firstTeamId
      const team1Score = isTeam1Home ? match.score.fullTime.home : match.score.fullTime.away
      const team2Score = isTeam1Home ? match.score.fullTime.away : match.score.fullTime.home

      team1Goals += team1Score
      team2Goals += team2Score

      if (team1Score > team2Score) {
        team1Wins++
      } else if (team2Score > team1Score) {
        team2Wins++
      } else {
        draws++
      }
    })

    setStats({
      team1Wins,
      team2Wins,
      draws,
      team1Goals,
      team2Goals,
      totalMatches: matches.length,
    })
  }

  useEffect(() => {
    if (firstTeamId && secondTeamId) {
      fetchH2H()
    }
  }, [firstTeamId, secondTeamId])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <Loader2 className="w-6 h-6 animate-spin text-primary mb-2" />
        <p className="text-xs text-slate-400">H2H verisi yükleniyor...</p>
      </div>
    )
  }

  if (error && (!matches.length || !stats)) {
    return (
      <div className="text-center p-4">
        <p className="text-sm text-red-400 mb-2">{error}</p>
        <Button variant="outline" size="sm" onClick={() => fetchH2H()}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Yeniden Dene
        </Button>
      </div>
    )
  }

  if (!stats || matches.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Karşılıklı Maç Analizi</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground">Karşılıklı maç verisi bulunamadı</p>
        </CardContent>
      </Card>
    )
  }

  const pieData = [
    { name: `${firstTeamName} Galibiyetleri`, value: stats.team1Wins, color: "#10b981" },
    { name: "Beraberlikler", value: stats.draws, color: "#f59e0b" },
    { name: `${secondTeamName} Galibiyetleri`, value: stats.team2Wins, color: "#3b82f6" },
  ]

  const barData = [
    { name: firstTeamName, goals: stats.team1Goals, color: "#10b981" },
    { name: secondTeamName, goals: stats.team2Goals, color: "#3b82f6" },
  ]

  const recentMatches = matches.slice(0, 5).map((match) => {
    const isTeam1Home = match.homeTeam.id.toString() === firstTeamId
    const team1Score = isTeam1Home ? match.score.fullTime.home : match.score.fullTime.away
    const team2Score = isTeam1Home ? match.score.fullTime.away : match.score.fullTime.home
    const date = new Date(match.utcDate).toLocaleDateString()

    return {
      date,
      result: `${firstTeamName} ${team1Score} - ${team2Score} ${secondTeamName}`,
    }
  })

  return (
    <Card className="w-full betting-card">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-bold">Karşılıklı Maç Analizi</CardTitle>
        <Button variant="outline" size="sm" onClick={() => fetchH2H(false)} disabled={refreshing}>
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
          Yenile
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-secondary/30 p-4 rounded-lg text-center">
            <h3 className="text-lg font-semibold mb-1">{firstTeamName} Galibiyetleri</h3>
            <p className="text-3xl font-bold text-green-500">{stats.team1Wins}</p>
            <p className="text-sm text-muted-foreground">
              Galibiyet oranı: {((stats.team1Wins / stats.totalMatches) * 100).toFixed(1)}%
            </p>
          </div>

          <div className="bg-secondary/30 p-4 rounded-lg text-center">
            <h3 className="text-lg font-semibold mb-1">Beraberlikler</h3>
            <p className="text-3xl font-bold text-amber-500">{stats.draws}</p>
            <p className="text-sm text-muted-foreground">
              Beraberlik oranı: {((stats.draws / stats.totalMatches) * 100).toFixed(1)}%
            </p>
          </div>

          <div className="bg-secondary/30 p-4 rounded-lg text-center">
            <h3 className="text-lg font-semibold mb-1">{secondTeamName} Galibiyetleri</h3>
            <p className="text-3xl font-bold text-blue-500">{stats.team2Wins}</p>
            <p className="text-sm text-muted-foreground">
              Galibiyet oranı: {((stats.team2Wins / stats.totalMatches) * 100).toFixed(1)}%
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-3">Maç Sonuçları</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">Atılan Goller</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="goals" name="Goller">
                    {barData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-3">Son Maçlar</h3>
          <div className="space-y-2">
            {recentMatches.map((match, index) => (
              <div key={index} className="p-3 rounded-md bg-secondary/30 flex justify-between items-center">
                <span className="text-sm text-muted-foreground">{match.date}</span>
                <span className="font-medium">{match.result}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
