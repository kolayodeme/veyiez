"use client"

import { Skeleton } from "@/components/ui/skeleton"
import { useState, useEffect, useRef } from "react"
import { getLiveMatches, getAllLeagues } from "@/lib/football-api"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import {
  AlertCircle,
  RefreshCw,
  Loader2,
  Timer,
  BarChart2,
  Clock,
  StickerIcon as Stadium,
  MessageSquare,
} from "lucide-react"
import { useTranslation } from "./language-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cacheService } from "@/lib/cache-service"
import { MatchDetails } from "./match-details"
import { Textarea } from "@/components/ui/textarea"
import { MatchPrediction } from "./match-prediction"

interface Player {
  time: string
  home_scorer?: string
  away_scorer?: string
  home_assist?: string
  away_assist?: string
  score?: string
  home_fault?: string
  away_fault?: string
  card?: string
  info?: string
  score_info_time?: string
}

interface Match {
  match_id: string
  match_status: string
  match_time: string
  match_hometeam_name: string
  match_hometeam_score: string
  match_awayteam_name: string
  match_awayteam_score: string
  team_home_badge: string
  team_away_badge: string
  match_live: string
  goalscorer: Player[]
  cards: Player[]
  league_name: string
  country_name: string
  league_logo?: string
  country_logo?: string
  substitutions: {
    home: Player[]
    away: Player[]
  }
  match_hometeam_id: string
  match_awayteam_id: string
  match_stadium?: string
  match_referee?: string
  league_id?: string
}

interface League {
  league_id: string
  league_name: string
  country_id: string
  country_name: string
  league_logo?: string
}

interface MatchComment {
  id: string
  matchId: string
  text: string
  timestamp: number
}

export function LiveMatches() {
  const [matches, setMatches] = useState<Match[]>([])
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null)
  const [leagues, setLeagues] = useState<League[]>([])
  const [selectedLeague, setSelectedLeague] = useState<string>("all-leagues")
  const { t } = useTranslation()
  const selectedMatchRef = useRef<HTMLDivElement>(null)
  const [isLoadingDetails, setIsLoadingDetails] = useState<boolean>(false)
  const [comments, setComments] = useState<MatchComment[]>([])
  const [newComment, setNewComment] = useState<string>("")
  const [activeTab, setActiveTab] = useState<string>("details")

  const fetchMatches = async () => {
    try {
      setLoading(true)
      setError(null)

      // Try to get from cache first to show something immediately
      const cachedMatches = cacheService.get("live_matches")
      if (cachedMatches) {
        setMatches(cachedMatches)
        setFilteredMatches(
          selectedLeague === "all-leagues"
            ? cachedMatches
            : cachedMatches.filter((match) => {
                const leagueInfo = leagues.find((l) => l.league_id === selectedLeague)
                return match.league_name === leagueInfo?.league_name
              }),
        )
      }

      // Then fetch fresh data
      const data = await getLiveMatches()
      if (Array.isArray(data) && data.length > 0) {
        setMatches(data)
        setFilteredMatches(
          selectedLeague === "all-leagues"
            ? data
            : data.filter((match) => {
                const leagueInfo = leagues.find((l) => l.league_id === selectedLeague)
                return match.league_name === leagueInfo?.league_name
              }),
        )

        // Cache the data
        cacheService.set("live_matches", data, 30 * 1000) // Cache for 30 seconds
      } else {
        setMatches([])
        setFilteredMatches([])
      }
    } catch (err) {
      console.error("Error fetching live matches:", err)
      setError(t("error"))
    } finally {
      setLoading(false)
    }
  }

  const fetchLeagues = async () => {
    try {
      // Try to get from cache first
      const cachedLeagues = cacheService.get("all_leagues")
      if (cachedLeagues) {
        setLeagues(cachedLeagues)
      }

      const data = await getAllLeagues()
      if (Array.isArray(data) && data.length > 0) {
        setLeagues(data)
        cacheService.set("all_leagues", data, 30 * 60 * 1000) // Cache for 30 minutes
      } else {
        console.log("No leagues data found")
      }
    } catch (err) {
      console.error("Error fetching leagues:", err)
    }
  }

  useEffect(() => {
    fetchMatches()
    fetchLeagues()

    // Load comments from localStorage
    const savedComments = localStorage.getItem("match_comments")
    if (savedComments) {
      try {
        setComments(JSON.parse(savedComments))
      } catch (e) {
        console.error("Error parsing saved comments:", e)
      }
    }

    // Auto refresh every 30 seconds
    const interval = setInterval(() => {
      fetchMatches()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (selectedLeague && selectedLeague !== "all-leagues") {
      const filtered = matches.filter((match) => {
        const leagueInfo = leagues.find((l) => l.league_id === selectedLeague)
        return match.league_name === leagueInfo?.league_name
      })
      setFilteredMatches(filtered)
    } else {
      setFilteredMatches(matches)
    }
  }, [selectedLeague, matches, leagues])

  // Scroll to selected match when data refreshes
  useEffect(() => {
    if (selectedMatch && selectedMatchRef.current) {
      setTimeout(() => {
        selectedMatchRef.current?.scrollIntoView({ behavior: "smooth", block: "center" })
      }, 100)
    }
  }, [filteredMatches, selectedMatch])

  // Save comments to localStorage when they change
  useEffect(() => {
    localStorage.setItem("match_comments", JSON.stringify(comments))
  }, [comments])

  const getStatusBadge = (status: string) => {
    if (status === "HT")
      return (
        <Badge variant="outline" className="bg-green-900/30 text-green-400 border-green-700/50">
          {t("halfTime")}
        </Badge>
      )
    if (status === "FT")
      return (
        <Badge variant="outline" className="bg-slate-700 text-slate-300 border-slate-600">
          {t("fullTime")}
        </Badge>
      )
    return (
      <Badge variant="destructive" className="animate-pulse bg-red-600 glow-red flex items-center">
        <Timer className="w-3 h-3 mr-1" />
        {t("live")}
      </Badge>
    )
  }

  const handleMatchClick = (matchId: string) => {
    setIsLoadingDetails(true)
    if (selectedMatch === matchId) {
      setSelectedMatch(null)
      setIsLoadingDetails(false)
      setActiveTab("details")
    } else {
      setSelectedMatch(matchId)
      setActiveTab("details")
      // Simulate loading time for details
      setTimeout(() => {
        setIsLoadingDetails(false)
      }, 500)
    }
  }

  const handleAddComment = (matchId: string) => {
    if (!newComment.trim()) return

    const comment: MatchComment = {
      id: Date.now().toString(),
      matchId,
      text: newComment,
      timestamp: Date.now(),
    }

    setComments([...comments, comment])
    setNewComment("")
  }

  const getMatchComments = (matchId: string) => {
    return comments.filter((comment) => comment.matchId === matchId)
  }

  const formatCommentTime = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  if (loading && matches.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-green-400 glow-text-green">{t("liveMatches")}</h2>
          <Skeleton className="w-24 h-8 bg-slate-700" />
        </div>

        <div className="flex items-center justify-center p-8">
          <Loader2 className="w-8 h-8 animate-spin text-green-500" />
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive" className="bg-red-900/50 border-red-700">
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" size="sm" className="mt-2 border-red-700 text-white" onClick={fetchMatches}>
          <RefreshCw className="w-4 h-4 mr-2" />
          {t("retry")}
        </Button>
      </Alert>
    )
  }

  if (matches.length === 0) {
    return (
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-green-400 glow-text-green">{t("liveMatches")}</h2>
        <Card className="bg-gradient-to-r from-slate-800 to-slate-900 border-green-700/30">
          <CardContent className="p-6 text-center">
            <Clock className="w-8 h-8 mx-auto mb-2 text-green-500" />
            <p className="text-green-400">{t("noLiveMatches")}</p>
            <p className="text-xs text-slate-400 mt-1">Şu anda canlı maç bulunmuyor. Daha sonra tekrar kontrol edin.</p>
            <Button variant="outline" size="sm" className="mt-4" onClick={fetchMatches}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Yenile
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-3 max-w-md mx-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-green-400 glow-text-green">{t("liveMatches")}</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={fetchMatches}
          className="flex items-center bg-green-900/30 border-green-700/50 text-green-400 hover:bg-green-800/50"
        >
          <RefreshCw className="w-3 h-3 mr-1" />
          {t("retry")}
        </Button>
      </div>

      <div className="mb-3">
        <Select value={selectedLeague} onValueChange={setSelectedLeague}>
          <SelectTrigger className="text-xs bg-slate-800 border-green-700/30 text-white">
            <SelectValue placeholder="Tüm Ligler" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-green-700/30">
            <SelectItem value="all-leagues" className="text-xs">
              Tüm Ligler
            </SelectItem>
            {leagues.map((league) => (
              <SelectItem key={league.league_id} value={league.league_id} className="text-xs">
                <div className="flex items-center">
                  {league.league_logo && (
                    <img
                      src={league.league_logo || "/placeholder.svg"}
                      alt={league.league_name}
                      className="w-4 h-4 mr-2 rounded-full"
                    />
                  )}
                  {league.league_name} ({league.country_name})
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 gap-2">
        {filteredMatches.map((match) => (
          <div key={match.match_id} ref={match.match_id === selectedMatch ? selectedMatchRef : null}>
            <Card
              className={`cursor-pointer transition-colors bg-gradient-to-r from-slate-800 to-slate-900 border-green-700/30 hover:border-green-600/50 ${
                selectedMatch === match.match_id ? "border-green-500 glow-green" : ""
              }`}
              onClick={() => handleMatchClick(match.match_id)}
            >
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    {match.league_logo && (
                      <img
                        src={match.league_logo || "/placeholder.svg"}
                        alt={match.league_name}
                        className="w-5 h-5 mr-1 rounded-full"
                      />
                    )}
                    <Badge
                      variant="outline"
                      className="text-[10px] px-1 py-0 border-green-700/30 text-green-400 bg-green-900/20"
                    >
                      {match.league_name}
                    </Badge>
                  </div>
                  <div>{getStatusBadge(match.match_status)}</div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 flex-1">
                    <div className="w-8 h-8 overflow-hidden rounded-full bg-slate-700 flex-shrink-0">
                      {match.team_home_badge ? (
                        <img
                          src={match.team_home_badge || "/placeholder.svg"}
                          alt={match.match_hometeam_name}
                          className="object-cover w-full h-full"
                          onError={(e) => {
                            ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=32&width=32"
                          }}
                        />
                      ) : (
                        <div className="flex items-center justify-center w-full h-full text-xs font-bold text-white">
                          {match.match_hometeam_name.substring(0, 1)}
                        </div>
                      )}
                    </div>
                    <span className="text-sm font-medium text-green-400 flex-shrink truncate">
                      {match.match_hometeam_name}
                    </span>
                  </div>

                  <div className="flex flex-col items-center mx-2">
                    <div className="flex items-center space-x-1 bg-green-900/30 px-3 py-1 rounded-md border border-green-700/30">
                      <span className="text-xl font-bold text-green-400">{match.match_hometeam_score}</span>
                      <span className="text-sm text-white">-</span>
                      <span className="text-xl font-bold text-yellow-400">{match.match_awayteam_score}</span>
                    </div>
                    <div className="mt-1 text-[10px] text-slate-400">{match.match_time}'</div>
                  </div>

                  <div className="flex items-center space-x-2 flex-1 justify-end">
                    <span className="text-sm font-medium text-yellow-400 flex-shrink truncate text-right">
                      {match.match_awayteam_name}
                    </span>
                    <div className="w-8 h-8 overflow-hidden rounded-full bg-slate-700 flex-shrink-0">
                      {match.team_away_badge ? (
                        <img
                          src={match.team_away_badge || "/placeholder.svg"}
                          alt={match.match_awayteam_name}
                          className="object-cover w-full h-full"
                          onError={(e) => {
                            ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=32&width=32"
                          }}
                        />
                      ) : (
                        <div className="flex items-center justify-center w-full h-full text-xs font-bold text-white">
                          {match.match_awayteam_name.substring(0, 1)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {match.match_stadium && (
                  <div className="mt-2 flex items-center justify-center text-xs text-slate-400">
                    <Stadium className="w-3 h-3 mr-1" />
                    <span>{match.match_stadium}</span>
                  </div>
                )}

                <div className="mt-3">
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full text-xs bg-green-900/30 border-green-700/30 text-green-400 hover:bg-green-800/50"
                    onClick={() => handleMatchClick(match.match_id)}
                  >
                    <BarChart2 className="w-3 h-3 mr-1" />
                    {selectedMatch === match.match_id ? "Detayları Gizle" : "Maç Detayları"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {selectedMatch === match.match_id && (
              <div className="mt-2">
                {isLoadingDetails ? (
                  <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
                    <CardContent className="p-4 flex justify-center">
                      <Loader2 className="w-6 h-6 animate-spin text-green-500" />
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
                    <CardContent className="p-3">
                      <div className="mb-4">
                        <div className="flex border-b border-green-700/30 mb-2">
                          <button
                            className={`px-3 py-1 text-xs font-medium ${
                              activeTab === "details" ? "border-b-2 border-green-500 text-green-400" : "text-slate-400"
                            }`}
                            onClick={() => setActiveTab("details")}
                          >
                            Detaylar
                          </button>
                          <button
                            className={`px-3 py-1 text-xs font-medium ${
                              activeTab === "prediction"
                                ? "border-b-2 border-green-500 text-green-400"
                                : "text-slate-400"
                            }`}
                            onClick={() => setActiveTab("prediction")}
                          >
                            Tahmin
                          </button>
                          <button
                            className={`px-3 py-1 text-xs font-medium ${
                              activeTab === "comments" ? "border-b-2 border-green-500 text-green-400" : "text-slate-400"
                            }`}
                            onClick={() => setActiveTab("comments")}
                          >
                            Yorumlar
                          </button>
                        </div>

                        {activeTab === "details" && (
                          <MatchDetails
                            matchId={match.match_id}
                            homeTeam={match.match_hometeam_name}
                            awayTeam={match.match_awayteam_name}
                            homeTeamId={match.match_hometeam_id}
                            awayTeamId={match.match_awayteam_id}
                            isLive={match.match_status !== "FT"}
                          />
                        )}

                        {activeTab === "prediction" && (
                          <MatchPrediction
                            homeTeam={match.match_hometeam_name}
                            awayTeam={match.match_awayteam_name}
                            homeScore={Number.parseInt(match.match_hometeam_score) || 0}
                            awayScore={Number.parseInt(match.match_awayteam_score) || 0}
                            matchStatus={match.match_status}
                            homeTeamId={match.match_hometeam_id}
                            awayTeamId={match.match_awayteam_id}
                            isLive={match.match_status !== "FT"}
                          />
                        )}

                        {activeTab === "comments" && (
                          <div className="space-y-3">
                            <h3 className="text-sm font-medium text-green-400">Maç Yorumları</h3>

                            <div className="space-y-2 max-h-60 overflow-y-auto p-1">
                              {getMatchComments(match.match_id).length > 0 ? (
                                getMatchComments(match.match_id).map((comment) => (
                                  <div key={comment.id} className="bg-slate-700/30 p-2 rounded-md">
                                    <div className="flex justify-between items-center mb-1">
                                      <span className="text-xs font-medium text-green-400">Kullanıcı</span>
                                      <span className="text-xs text-slate-400">
                                        {formatCommentTime(comment.timestamp)}
                                      </span>
                                    </div>
                                    <p className="text-xs text-slate-300">{comment.text}</p>
                                  </div>
                                ))
                              ) : (
                                <div className="text-center py-4">
                                  <p className="text-xs text-slate-400">Henüz yorum yapılmamış</p>
                                </div>
                              )}
                            </div>

                            <div className="space-y-2">
                              <Textarea
                                placeholder="Maç hakkında yorumunuzu yazın..."
                                className="text-xs bg-slate-700/30 border-green-700/30 resize-none"
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                              />
                              <Button
                                size="sm"
                                className="w-full bg-green-700 hover:bg-green-600 text-white"
                                onClick={() => handleAddComment(match.match_id)}
                              >
                                <MessageSquare className="w-3 h-3 mr-1" />
                                Yorum Yap
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
