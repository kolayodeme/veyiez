"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Calendar, BarChart2, Timer, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { getLiveMatches } from "@/lib/football-api"
import { cacheService } from "@/lib/cache-service"

export function BottomNavigation() {
  const pathname = usePathname()
  const [liveMatchCount, setLiveMatchCount] = useState(0)

  useEffect(() => {
    // Önbellekten canlı maç sayısını kontrol et
    const cachedMatches = cacheService.get("live_matches")
    if (cachedMatches && Array.isArray(cachedMatches)) {
      setLiveMatchCount(cachedMatches.length)
    }

    // API'den canlı maç sayısını çek
    const fetchLiveMatchCount = async () => {
      try {
        const matches = await getLiveMatches()
        if (Array.isArray(matches)) {
          setLiveMatchCount(matches.length)
        }
      } catch (error) {
        console.error("Canlı maç sayısı çekilirken hata:", error)
      }
    }

    fetchLiveMatchCount()

    // Her 60 saniyede bir güncelle
    const interval = setInterval(fetchLiveMatchCount, 60000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-black to-slate-900 border-t border-green-700/30 py-2 px-4 z-50">
      <div className="flex justify-around items-center">
        <Link
          href="/"
          className={`flex flex-col items-center p-2 ${
            pathname === "/" ? "text-green-400" : "text-slate-400 hover:text-green-400"
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-xs mt-1">Ana Sayfa</span>
        </Link>

        <Link
          href="/upcoming"
          className={`flex flex-col items-center p-2 ${
            pathname === "/upcoming" ? "text-green-400" : "text-slate-400 hover:text-green-400"
          }`}
        >
          <Calendar className="w-5 h-5" />
          <span className="text-xs mt-1">Yaklaşan</span>
        </Link>

        <Link
          href="/live"
          className={`flex flex-col items-center p-2 relative ${
            pathname === "/live" ? "text-green-400" : "text-slate-400 hover:text-green-400"
          }`}
        >
          <Timer className="w-5 h-5" />
          <span className="text-xs mt-1">Canlı</span>
          {liveMatchCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px]"
            >
              {liveMatchCount}
            </Badge>
          )}
        </Link>

        <Link
          href="/statistics"
          className={`flex flex-col items-center p-2 ${
            pathname === "/statistics" ? "text-green-400" : "text-slate-400 hover:text-green-400"
          }`}
        >
          <BarChart2 className="w-5 h-5" />
          <span className="text-xs mt-1">İstatistik</span>
        </Link>

        <Link
          href="/profile"
          className={`flex flex-col items-center p-2 ${
            pathname === "/profile" ? "text-green-400" : "text-slate-400 hover:text-green-400"
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-xs mt-1">Profil</span>
        </Link>
      </div>
    </div>
  )
}
