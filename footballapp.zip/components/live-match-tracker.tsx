"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { getLiveMatches, getMatchDetails, getTeamForm, getUpcomingMatches } from "@/lib/football-api"
import { cacheService } from "@/lib/cache-service"
import { useTranslation } from "./language-provider"
import { MatchPrediction } from "./match-prediction"
import {
  AlertCircle,
  RefreshCw,
  Loader2,
  Timer,
  Bell,
  BellOff,
  MessageSquare,
  History,
  Zap,
  Calendar,
  Share2,
} from "lucide-react"

interface LiveMatchTrackerProps {
  initialMatchId?: string
}

export function LiveMatchTracker({ initialMatchId }: LiveMatchTrackerProps) {
  const [matches, setMatches] = useState<any[]>([])
  const [upcomingMatches, setUpcomingMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedMatch, setSelectedMatch] = useState<string | null>(initialMatchId || null)
  const [matchDetails, setMatchDetails] = useState<any>(null)
  const [loadingDetails, setLoadingDetails] = useState(false)
  const [notifications, setNotifications] = useState<boolean>(
    typeof window !== "undefined" ? localStorage.getItem("notifications") === "true" : false,
  )
  const [matchEvents, setMatchEvents] = useState<any[]>([])
  const [homeTeamForm, setHomeTeamForm] = useState<string[]>([])
  const [awayTeamForm, setAwayTeamForm] = useState<string[]>([])
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())
  const [refreshProgress, setRefreshProgress] = useState(100)
  const refreshInterval = useRef<NodeJS.Timeout | null>(null)
  const eventsRef = useRef<HTMLDivElement>(null)
  const { t } = useTranslation()
  const { toast } = useToast()

  // Maçları çek
  const fetchMatches = async () => {
    try {
      setError(null)

      // Önbellekten veri çek
      const cachedMatches = cacheService.get("live_matches")
      if (cachedMatches && !loading) {
        setMatches(cachedMatches)
      }

      // API'den veri çek
      const data = await getLiveMatches()
      if (Array.isArray(data) && data.length > 0) {
        setMatches(data)

        // Eğer seçili maç yoksa ilk maçı seç
        if (!selectedMatch && data.length > 0) {
          setSelectedMatch(data[0].match_id)
        }

        // Yeni olayları kontrol et ve bildirim gönder
        if (notifications && cachedMatches && cachedMatches.length > 0) {
          checkForNewEvents(cachedMatches, data)
        }
      } else {
        setMatches([])
        if (!selectedMatch) {
          // Canlı maç yoksa yaklaşan maçları çek
          fetchUpcomingMatches()
        }
      }

      setLastRefresh(new Date())
      setRefreshProgress(100)
    } catch (err) {
      console.error("Canlı maçlar çekilirken hata:", err)
      setError("Canlı maçlar yüklenirken bir hata oluştu.")
    } finally {
      setLoading(false)
    }
  }

  // Yaklaşan maçları çek
  const fetchUpcomingMatches = async () => {
    try {
      // Bugünün tarihi
      const today = new Date()
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)

      // Tarih formatı: YYYY-MM-DD
      const fromDate = today.toISOString().split("T")[0]
      const toDate = tomorrow.toISOString().split("T")[0]

      const data = await getUpcomingMatches(fromDate, toDate)
      if (Array.isArray(data) && data.length > 0) {
        setUpcomingMatches(data)

        // Eğer seçili maç yoksa ve canlı maç yoksa ilk yaklaşan maçı seç
        if (!selectedMatch && matches.length === 0) {
          setSelectedMatch(data[0].match_id)
        }
      } else {
        setUpcomingMatches([])
      }
    } catch (err) {
      console.error("Yaklaşan maçlar çekilirken hata:", err)
    }
  }

  // Maç detaylarını çek
  const fetchMatchDetails = async (matchId: string) => {
    if (!matchId) return

    setLoadingDetails(true)

    try {
      const details = await getMatchDetails(matchId)

      if (Array.isArray(details) && details.length > 0) {
        setMatchDetails(details[0])

        // Takım formlarını çek
        if (details[0].match_hometeam_id && details[0].match_awayteam_id) {
          fetchTeamForms(details[0].match_hometeam_id, details[0].match_awayteam_id)
        }

        // Maç olaylarını ayıkla
        const events = []

        // Goller
        if (details[0].goalscorer && details[0].goalscorer.length > 0) {
          details[0].goalscorer.forEach((goal: any) => {
            events.push({
              type: "goal",
              time: goal.time,
              team: goal.home_scorer ? "home" : "away",
              player: goal.home_scorer || goal.away_scorer,
              score: goal.score,
              assist: goal.home_assist || goal.away_assist,
            })
          })
        }

        // Kartlar
        if (details[0].cards && details[0].cards.length > 0) {
          details[0].cards.forEach((card: any) => {
            events.push({
              type: "card",
              time: card.time,
              team: card.home_fault ? "home" : "away",
              player: card.home_fault || card.away_fault,
              card: card.card,
            })
          })
        }

        // Olayları zamana göre sırala
        events.sort((a, b) => {
          return Number.parseInt(a.time) - Number.parseInt(b.time)
        })

        setMatchEvents(events)
      } else {
        setMatchDetails(null)
        setMatchEvents([])
      }
    } catch (err) {
      console.error("Maç detayları çekilirken hata:", err)
    } finally {
      setLoadingDetails(false)
    }
  }

  // Takım formlarını çek
  const fetchTeamForms = async (homeTeamId: string, awayTeamId: string) => {
    try {
      const [homeForm, awayForm] = await Promise.all([getTeamForm(homeTeamId), getTeamForm(awayTeamId)])
      setHomeTeamForm(homeForm || [])
      setAwayTeamForm(awayForm || [])
    } catch (err) {
      console.error("Takım formları çekilirken hata:", err)
    }
  }

  // Yeni olayları kontrol et
  const checkForNewEvents = (oldMatches: any[], newMatches: any[]) => {
    newMatches.forEach((newMatch) => {
      const oldMatch = oldMatches.find((m) => m.match_id === newMatch.match_id)

      if (oldMatch) {
        // Skor değişikliği kontrolü
        if (
          oldMatch.match_hometeam_score !== newMatch.match_hometeam_score ||
          oldMatch.match_awayteam_score !== newMatch.match_awayteam_score
        ) {
          // Hangi takım gol attı?
          const homeScored =
            Number.parseInt(newMatch.match_hometeam_score) > Number.parseInt(oldMatch.match_hometeam_score)
          const awayScored =
            Number.parseInt(newMatch.match_awayteam_score) > Number.parseInt(oldMatch.match_awayteam_score)

          if (homeScored) {
            showNotification(
              "⚽ GOL!",
              `${newMatch.match_hometeam_name} gol attı! ${newMatch.match_hometeam_name} ${newMatch.match_hometeam_score}-${newMatch.match_awayteam_score} ${newMatch.match_awayteam_name}`,
            )
          } else if (awayScored) {
            showNotification(
              "⚽ GOL!",
              `${newMatch.match_awayteam_name} gol attı! ${newMatch.match_hometeam_name} ${newMatch.match_hometeam_score}-${newMatch.match_awayteam_score} ${newMatch.match_awayteam_name}`,
            )
          }
        }

        // Maç durumu değişikliği kontrolü
        if (oldMatch.match_status !== newMatch.match_status) {
          if (newMatch.match_status === "HT") {
            showNotification(
              "🏁 DEVRE ARASI",
              `${newMatch.match_hometeam_name} ${newMatch.match_hometeam_score}-${newMatch.match_awayteam_score} ${newMatch.match_awayteam_name}`,
            )
          } else if (newMatch.match_status === "FT") {
            showNotification(
              "🏁 MAÇ SONU",
              `${newMatch.match_hometeam_name} ${newMatch.match_hometeam_score}-${newMatch.match_awayteam_score} ${newMatch.match_awayteam_name}`,
            )
          }
        }
      }
    })
  }

  // Bildirim göster
  const showNotification = (title: string, body: string) => {
    // Tarayıcı bildirimi
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "granted") {
        new Notification(title, { body })
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then((permission) => {
          if (permission === "granted") {
            new Notification(title, { body })
          }
        })
      }
    }

    // Toast bildirimi
    toast({
      title,
      description: body,
      duration: 5000,
    })
  }

  // Bildirim izni iste
  const requestNotificationPermission = async () => {
    if (typeof window !== "undefined" && "Notification" in window) {
      const permission = await Notification.requestPermission()
      if (permission === "granted") {
        setNotifications(true)
        localStorage.setItem("notifications", "true")
        toast({
          title: "Bildirimler açıldı",
          description: "Artık gol, kart ve diğer önemli olaylar için bildirim alacaksınız.",
          duration: 3000,
        })
      } else {
        toast({
          title: "Bildirim izni reddedildi",
          description: "Bildirim almak için tarayıcı izinlerini kontrol edin.",
          variant: "destructive",
          duration: 3000,
        })
      }
    }
  }

  // Bildirim durumunu değiştir
  const toggleNotifications = () => {
    if (!notifications) {
      requestNotificationPermission()
    } else {
      setNotifications(false)
      localStorage.setItem("notifications", "false")
      toast({
        title: "Bildirimler kapatıldı",
        description: "Artık maç olayları için bildirim almayacaksınız.",
        duration: 3000,
      })
    }
  }

  // Otomatik yenileme durumunu değiştir
  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh)
  }

  // Maç paylaş
  const shareMatch = () => {
    if (!matchDetails) return

    const matchText = `${matchDetails.match_hometeam_name} ${matchDetails.match_hometeam_score}-${matchDetails.match_awayteam_score} ${matchDetails.match_awayteam_name} | ${matchDetails.league_name}`
    const shareUrl = window.location.href

    if (navigator.share) {
      navigator
        .share({
          title: "Futbol Maçı",
          text: matchText,
          url: shareUrl,
        })
        .catch((error) => console.log("Paylaşım hatası:", error))
    } else {
      // Kopyala
      navigator.clipboard.writeText(`${matchText} - ${shareUrl}`).then(
        () => {
          toast({
            title: "Bağlantı kopyalandı",
            description: "Maç bilgisi panoya kopyalandı.",
            duration: 3000,
          })
        },
        (err) => {
          console.error("Kopyalama hatası:", err)
        },
      )
    }
  }

  // İlk yükleme
  useEffect(() => {
    fetchMatches()
    fetchUpcomingMatches()

    // Bildirim izni kontrolü
    if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
      setNotifications(true)
    }

    return () => {
      if (refreshInterval.current) {
        clearInterval(refreshInterval.current)
      }
    }
  }, [])

  // Otomatik yenileme
  useEffect(() => {
    if (refreshInterval.current) {
      clearInterval(refreshInterval.current)
    }

    if (autoRefresh) {
      const REFRESH_INTERVAL = 15000 // 15 saniye

      refreshInterval.current = setInterval(() => {
        const elapsed = new Date().getTime() - lastRefresh.getTime()
        const progress = 100 - (elapsed / REFRESH_INTERVAL) * 100
        setRefreshProgress(Math.max(0, progress))

        if (elapsed >= REFRESH_INTERVAL) {
          fetchMatches()
          if (selectedMatch) {
            fetchMatchDetails(selectedMatch)
          }
        }
      }, 1000)
    }

    return () => {
      if (refreshInterval.current) {
        clearInterval(refreshInterval.current)
      }
    }
  }, [autoRefresh, lastRefresh, selectedMatch])

  // Seçili maç değiştiğinde detayları çek
  useEffect(() => {
    if (selectedMatch) {
      fetchMatchDetails(selectedMatch)
    }
  }, [selectedMatch])

  // Yeni olaylar geldiğinde otomatik kaydır
  useEffect(() => {
    if (eventsRef.current) {
      eventsRef.current.scrollTop = eventsRef.current.scrollHeight
    }
  }, [matchEvents])

  // Maç durumu badgesi
  const getStatusBadge = (status: string) => {
    if (status === "HT")
      return (
        <Badge variant="outline" className="bg-green-900/30 text-green-400 border-green-700/50">
          DEVRE ARASI
        </Badge>
      )
    if (status === "FT")
      return (
        <Badge variant="outline" className="bg-slate-700 text-slate-300 border-slate-600">
          MAÇ SONU
        </Badge>
      )
    if (status === "NS" || !status)
      return (
        <Badge variant="outline" className="bg-blue-900/30 text-blue-400 border-blue-700/50">
          <Calendar className="w-3 h-3 mr-1" />
          YAKLAŞAN
        </Badge>
      )
    return (
      <Badge variant="destructive" className="animate-pulse bg-red-600 glow-red flex items-center">
        <Timer className="w-3 h-3 mr-1" />
        CANLI
      </Badge>
    )
  }

  // Olay ikonu
  const getEventIcon = (type: string, cardType?: string) => {
    switch (type) {
      case "goal":
        return <span className="text-lg">⚽</span>
      case "card":
        return cardType === "yellow card" ? (
          <div className="w-4 h-6 bg-yellow-500 rounded-sm"></div>
        ) : (
          <div className="w-4 h-6 bg-red-600 rounded-sm"></div>
        )
      default:
        return <span className="text-lg">📝</span>
    }
  }

  // Form badgesi
  const getFormBadge = (form: string) => {
    switch (form) {
      case "W":
        return <Badge className="bg-green-600 text-white">K</Badge>
      case "D":
        return <Badge className="bg-yellow-600 text-white">B</Badge>
      case "L":
        return <Badge className="bg-red-600 text-white">M</Badge>
      default:
        return <Badge className="bg-slate-600 text-white">-</Badge>
    }
  }

  // Yükleme durumu
  if (loading && matches.length === 0 && upcomingMatches.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-green-400 glow-text-green">Canlı Maç Takibi</h2>
          <Skeleton className="w-24 h-8 bg-slate-700" />
        </div>

        <div className="flex items-center justify-center p-8">
          <Loader2 className="w-8 h-8 animate-spin text-green-500" />
        </div>
      </div>
    )
  }

  // Hata durumu
  if (error) {
    return (
      <Alert variant="destructive" className="bg-red-900/50 border-red-700">
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" size="sm" className="mt-2 border-red-700 text-white" onClick={fetchMatches}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Yeniden Dene
        </Button>
      </Alert>
    )
  }

  // Maç yok
  if (matches.length === 0 && upcomingMatches.length === 0) {
    return (
      <Card className="bg-gradient-to-r from-slate-800 to-slate-900 border-green-700/30">
        <CardContent className="p-6 text-center">
          <Timer className="w-8 h-8 mx-auto mb-2 text-green-500" />
          <p className="text-green-400">Şu anda canlı veya yaklaşan maç bulunmuyor</p>
          <p className="text-xs text-slate-400 mt-1">Daha sonra tekrar kontrol edin.</p>
          <Button variant="outline" size="sm" className="mt-4" onClick={fetchMatches}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Yenile
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={fetchMatches} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </Button>
          <div className="flex items-center space-x-2">
            <Switch id="auto-refresh" checked={autoRefresh} onCheckedChange={toggleAutoRefresh} />
            <Label htmlFor="auto-refresh">Otomatik Yenile</Label>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={toggleNotifications}>
            {notifications ? (
              <>
                <Bell className="w-4 h-4 mr-2 text-green-400" />
                Bildirimler Açık
              </>
            ) : (
              <>
                <BellOff className="w-4 h-4 mr-2" />
                Bildirimler Kapalı
              </>
            )}
          </Button>
        </div>
      </div>

      {autoRefresh && (
        <Progress value={refreshProgress} className="h-1 w-full bg-slate-700" indicatorClassName="bg-green-500" />
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Maç listesi */}
        <div className="md:col-span-1">
          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
            <CardHeader className="p-3">
              <CardTitle className="text-lg text-green-400">
                {matches.length > 0 ? "Canlı Maçlar" : "Yaklaşan Maçlar"}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <div className="space-y-1 p-2">
                  {/* Canlı maçlar */}
                  {matches.length > 0 &&
                    matches.map((match) => (
                      <div
                        key={match.match_id}
                        className={`p-2 rounded-md cursor-pointer transition-colors ${
                          selectedMatch === match.match_id
                            ? "bg-green-900/30 border border-green-500"
                            : "hover:bg-slate-700/50"
                        }`}
                        onClick={() => setSelectedMatch(match.match_id)}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <Badge variant="outline" className="text-[10px] px-1 py-0 bg-slate-800">
                            {match.league_name}
                          </Badge>
                          {getStatusBadge(match.match_status)}
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-6 h-6 rounded-full bg-slate-700 overflow-hidden">
                              {match.team_home_badge ? (
                                <img
                                  src={match.team_home_badge || "/placeholder.svg?height=24&width=24"}
                                  alt={match.match_hometeam_name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-xs">
                                  {match.match_hometeam_name.charAt(0)}
                                </div>
                              )}
                            </div>
                            <span className="text-xs text-green-400 truncate max-w-[80px]">
                              {match.match_hometeam_name}
                            </span>
                          </div>
                          <div className="flex items-center space-x-1 px-2 py-1 bg-slate-800 rounded">
                            <span className="text-sm font-bold text-green-400">{match.match_hometeam_score}</span>
                            <span className="text-xs text-white">-</span>
                            <span className="text-sm font-bold text-yellow-400">{match.match_awayteam_score}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-yellow-400 truncate max-w-[80px]">
                              {match.match_awayteam_name}
                            </span>
                            <div className="w-6 h-6 rounded-full bg-slate-700 overflow-hidden">
                              {match.team_away_badge ? (
                                <img
                                  src={match.team_away_badge || "/placeholder.svg?height=24&width=24"}
                                  alt={match.match_awayteam_name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-xs">
                                  {match.match_awayteam_name.charAt(0)}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="mt-1 text-center">
                          <span className="text-[10px] text-slate-400">{match.match_time}'</span>
                        </div>
                      </div>
                    ))}

                  {/* Yaklaşan maçlar */}
                  {matches.length === 0 &&
                    upcomingMatches.map((match) => (
                      <div
                        key={match.match_id}
                        className={`p-2 rounded-md cursor-pointer transition-colors ${
                          selectedMatch === match.match_id
                            ? "bg-blue-900/30 border border-blue-500"
                            : "hover:bg-slate-700/50"
                        }`}
                        onClick={() => setSelectedMatch(match.match_id)}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <Badge variant="outline" className="text-[10px] px-1 py-0 bg-slate-800">
                            {match.league_name}
                          </Badge>
                          <span className="text-xs text-slate-400">{match.match_time}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-6 h-6 rounded-full bg-slate-700 overflow-hidden">
                              {match.team_home_badge ? (
                                <img
                                  src={match.team_home_badge || "/placeholder.svg?height=24&width=24"}
                                  alt={match.match_hometeam_name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-xs">
                                  {match.match_hometeam_name.charAt(0)}
                                </div>
                              )}
                            </div>
                            <span className="text-xs text-blue-400 truncate max-w-[80px]">
                              {match.match_hometeam_name}
                            </span>
                          </div>
                          <span className="text-xs text-slate-400">vs</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-blue-400 truncate max-w-[80px]">
                              {match.match_awayteam_name}
                            </span>
                            <div className="w-6 h-6 rounded-full bg-slate-700 overflow-hidden">
                              {match.team_away_badge ? (
                                <img
                                  src={match.team_away_badge || "/placeholder.svg?height=24&width=24"}
                                  alt={match.match_awayteam_name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-xs">
                                  {match.match_awayteam_name.charAt(0)}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="mt-1 text-center">
                          <span className="text-[10px] text-slate-400">{match.match_date}</span>
                        </div>
                      </div>
                    ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Maç detayları */}
        <div className="md:col-span-2">
          {selectedMatch ? (
            loadingDetails ? (
              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 h-full">
                <CardContent className="p-6 flex items-center justify-center h-full">
                  <Loader2 className="w-8 h-8 animate-spin text-green-500" />
                </CardContent>
              </Card>
            ) : matchDetails ? (
              <div className="space-y-4">
                {/* Maç başlığı */}
                <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
                  <CardHeader className="p-3">
                    <div className="flex flex-col items-center">
                      <div className="flex items-center justify-between w-full mb-2">
                        <Badge variant="outline" className="bg-slate-800">
                          {matchDetails.league_name} - {matchDetails.country_name}
                        </Badge>
                        <div className="flex items-center space-x-2">
                          {getStatusBadge(matchDetails.match_status)}
                          <Button variant="ghost" size="icon" onClick={shareMatch}>
                            <Share2 className="w-4 h-4 text-slate-400" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between w-full">
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 rounded-full bg-slate-700 overflow-hidden mb-1">
                            {matchDetails.team_home_badge ? (
                              <img
                                src={matchDetails.team_home_badge || "/placeholder.svg?height=64&width=64"}
                                alt={matchDetails.match_hometeam_name}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=64&width=64"
                                }}
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-lg">
                                {matchDetails.match_hometeam_name.charAt(0)}
                              </div>
                            )}
                          </div>
                          <span className="text-base font-bold text-white">{matchDetails.match_hometeam_name}</span>
                          {/* Takım formu */}
                          <div className="flex space-x-1 mt-1">
                            {homeTeamForm.slice(0, 5).map((form, index) => (
                              <div key={index}>{getFormBadge(form)}</div>
                            ))}
                          </div>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="flex items-center space-x-4 bg-slate-800 px-6 py-3 rounded-lg mb-2">
                            <span className="text-3xl font-bold text-green-400">
                              {matchDetails.match_hometeam_score || "0"}
                            </span>
                            <div className="flex flex-col items-center">
                              {matchDetails.match_status !== "NS" && matchDetails.match_status !== "FT" ? (
                                <Badge variant="destructive" className="animate-pulse bg-red-600 mb-1">
                                  <Timer className="w-3 h-3 mr-1" />
                                  CANLI
                                </Badge>
                              ) : matchDetails.match_status === "FT" ? (
                                <Badge variant="outline" className="bg-slate-700 text-slate-300 mb-1">
                                  MAÇ SONU
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-blue-900/30 text-blue-400 mb-1">
                                  <Calendar className="w-3 h-3 mr-1" />
                                  YAKLAŞAN
                                </Badge>
                              )}
                              <span className="text-sm text-slate-400">
                                {matchDetails.match_status !== "NS"
                                  ? `${matchDetails.match_time}'`
                                  : matchDetails.match_time}
                              </span>
                            </div>
                            <span className="text-3xl font-bold text-yellow-400">
                              {matchDetails.match_awayteam_score || "0"}
                            </span>
                          </div>
                          <span className="text-sm text-slate-400">{matchDetails.match_date}</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 rounded-full bg-slate-700 overflow-hidden mb-1">
                            {matchDetails.team_away_badge ? (
                              <img
                                src={matchDetails.team_away_badge || "/placeholder.svg?height=64&width=64"}
                                alt={matchDetails.match_awayteam_name}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=64&width=64"
                                }}
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-lg">
                                {matchDetails.match_awayteam_name.charAt(0)}
                              </div>
                            )}
                          </div>
                          <span className="text-base font-bold text-white">{matchDetails.match_awayteam_name}</span>
                          {/* Takım formu */}
                          <div className="flex space-x-1 mt-1">
                            {awayTeamForm.slice(0, 5).map((form, index) => (
                              <div key={index}>{getFormBadge(form)}</div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                </Card>

                {/* Maç yorumu */}
                <Card className="bg-gradient-to-br from-green-900/20 to-slate-900 border-green-700/30">
                  <CardHeader className="p-3">
                    <CardTitle className="text-lg text-white flex items-center">
                      <MessageSquare className="w-5 h-5 mr-2 text-green-400" />
                      <span className="text-green-400">Maç Yorumu</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="bg-green-900/10 border border-green-700/30 rounded-lg p-4 text-base text-white">
                      {generateMatchComment(matchDetails, matchEvents)}
                    </div>
                  </CardContent>
                </Card>

                {/* Maç tahmini */}
                <MatchPrediction
                  homeTeam={matchDetails.match_hometeam_name}
                  awayTeam={matchDetails.match_awayteam_name}
                  homeScore={Number.parseInt(matchDetails.match_hometeam_score) || 0}
                  awayScore={Number.parseInt(matchDetails.match_awayteam_score) || 0}
                  matchStatus={matchDetails.match_status}
                  homeTeamId={matchDetails.match_hometeam_id}
                  awayTeamId={matchDetails.match_awayteam_id}
                  isLive={matchDetails.match_status !== "NS" && matchDetails.match_status !== "FT"}
                />

                {/* Maç olayları */}
                <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30">
                  <CardHeader className="p-3">
                    <CardTitle className="text-base text-white flex items-center">
                      <History className="w-4 h-4 mr-2 text-green-400" />
                      <span className="text-green-400">Maç Olayları</span>
                      {matchDetails.match_status !== "NS" && matchDetails.match_status !== "FT" && (
                        <Badge className="ml-2 text-[10px] animate-pulse bg-red-600 text-white">
                          <Zap className="w-2 h-2 mr-1" />
                          CANLI
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3">
                    <div className="bg-slate-800/50 rounded-md p-2">
                      <ScrollArea className="h-[200px]" ref={eventsRef}>
                        <div className="space-y-2">
                          {matchEvents.length > 0 ? (
                            matchEvents.map((event, index) => (
                              <div
                                key={index}
                                className={`p-2 rounded-md ${
                                  event.team === "home"
                                    ? "bg-green-900/20 border-l-4 border-green-500"
                                    : "bg-yellow-900/20 border-l-4 border-yellow-500"
                                }`}
                              >
                                <div className="flex items-center">
                                  <div className="w-8 text-center font-bold text-white">{event.time}'</div>
                                  <div className="w-6 text-center">{getEventIcon(event.type, event.card)}</div>
                                  <div className="ml-2 flex-1">
                                    {event.type === "goal" && (
                                      <div>
                                        <span className="font-medium text-white">{event.player}</span>
                                        <span className="text-xs text-slate-400 ml-1">
                                          {event.score && `(${event.score})`}
                                        </span>
                                        {event.assist && (
                                          <div className="text-xs text-slate-400">Asist: {event.assist}</div>
                                        )}
                                      </div>
                                    )}
                                    {event.type === "card" && (
                                      <div>
                                        <span className="font-medium text-white">{event.player}</span>
                                        <span className="text-xs text-slate-400 ml-1">
                                          ({event.card === "yellow card" ? "Sarı Kart" : "Kırmızı Kart"})
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-center py-4">
                              <p className="text-sm text-slate-400">
                                {matchDetails.match_status === "NS" ? "Maç henüz başlamadı" : "Henüz olay kaydedilmedi"}
                              </p>
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 h-full">
                <CardContent className="p-6 flex items-center justify-center h-full">
                  <div className="text-center">
                    <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                    <p className="text-yellow-400">Maç detayları bulunamadı</p>
                  </div>
                </CardContent>
              </Card>
            )
          ) : (
            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 h-full">
              <CardContent className="p-6 flex items-center justify-center h-full">
                <div className="text-center">
                  <MessageSquare className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                  <p className="text-slate-400">Detayları görüntülemek için bir maç seçin</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

// Maç yorumu oluştur
function generateMatchComment(matchDetails: any, matchEvents: any[] = []) {
  if (!matchDetails) return "Maç bilgisi bulunamadı."

  const homeTeam = matchDetails.match_hometeam_name
  const awayTeam = matchDetails.match_awayteam_name
  const homeScore = Number.parseInt(matchDetails.match_hometeam_score) || 0
  const awayScore = Number.parseInt(matchDetails.match_awayteam_score) || 0
  const matchStatus = matchDetails.match_status
  const matchMinute = Number.parseInt(matchDetails.match_time) || 0
  const scoreDiff = Math.abs(homeScore - awayScore)
  const totalGoals = homeScore + awayScore

  // Gol atan oyuncular
  const goalScorers = matchEvents
    .filter((event) => event.type === "goal")
    .map((event) => ({
      player: event.player,
      team: event.team === "home" ? homeTeam : awayTeam,
      minute: event.time,
    }))

  // Kart gören oyuncular
  const cardPlayers = matchEvents
    .filter((event) => event.type === "card")
    .map((event) => ({
      player: event.player,
      team: event.team === "home" ? homeTeam : awayTeam,
      cardType: event.card,
      minute: event.time,
    }))

  // Yaklaşan maç
  if (matchStatus === "NS") {
    return `${homeTeam} ve ${awayTeam} arasındaki karşılaşma henüz başlamadı. Bu önemli maçta iki takım da galibiyet için mücadele edecek. Takımların son form durumları ve karşılıklı maç istatistikleri, dengeli bir mücadele olacağını gösteriyor.`
  }

  // Maç sonu
  if (matchStatus === "FT") {
    let comment = ""

    if (homeScore === awayScore) {
      comment = `Maç ${homeScore}-${awayScore} berabere sonuçlandı. İki takım da birbirine denk bir performans sergiledi.`
    } else if (homeScore > awayScore) {
      comment = `${homeTeam}, ${awayTeam}'i ${homeScore}-${awayScore} mağlup etti. ${
        scoreDiff > 1 ? "Net bir galibiyet" : "Zorlu bir maçta kazanan taraf oldu"
      }.`
    } else {
      comment = `${awayTeam}, deplasmanda ${homeTeam}'i ${awayScore}-${homeScore} mağlup etmeyi başardı. ${
        scoreDiff > 1 ? "Etkileyici bir deplasman galibiyeti" : "Kritik puanları aldı"
      }.`
    }

    // Gol atan oyuncular
    if (goalScorers.length > 0) {
      const homeGoalScorers = goalScorers.filter((scorer) => scorer.team === homeTeam)
      const awayGoalScorers = goalScorers.filter((scorer) => scorer.team === awayTeam)

      if (homeGoalScorers.length > 0) {
        comment += ` ${homeTeam} adına ${homeGoalScorers.map((scorer) => scorer.player).join(", ")} gol kaydetti.`
      }

      if (awayGoalScorers.length > 0) {
        comment += ` ${awayTeam} adına ${awayGoalScorers.map((scorer) => scorer.player).join(", ")} gol kaydetti.`
      }
    }

    // Kart gören oyuncular
    if (cardPlayers.length > 0) {
      const redCards = cardPlayers.filter((player) => player.cardType === "red card")
      if (redCards.length > 0) {
        comment += ` Maçta ${redCards.map((player) => `${player.player} (${player.team})`).join(", ")} kırmızı kart gördü.`
      }
    }

    return comment
  }

  // Devre arası
  if (matchStatus === "HT") {
    let comment = ""

    if (homeScore === awayScore) {
      comment = `İlk yarı ${homeScore}-${awayScore} berabere tamamlandı. İkinci yarıda daha fazla gol görebiliriz.`
    } else if (homeScore > awayScore) {
      comment = `İlk yarı ${homeTeam} üstünlüğüyle ${homeScore}-${awayScore} tamamlandı. ${awayTeam} ikinci yarıda toparlanabilecek mi?`
    } else {
      comment = `İlk yarı ${awayTeam} üstünlüğüyle ${homeScore}-${awayScore} tamamlandı. ${homeTeam} ikinci yarıda skoru çevirebilecek mi?`
    }

    // Gol atan oyuncular
    if (goalScorers.length > 0) {
      comment += ` İlk yarıda ${goalScorers.map((scorer) => `${scorer.player} (${scorer.team})`).join(", ")} gol kaydetti.`
    }

    // Kart gören oyuncular
    if (cardPlayers.length > 0) {
      const yellowCards = cardPlayers.filter((player) => player.cardType === "yellow card")
      const redCards = cardPlayers.filter((player) => player.cardType === "red card")

      if (yellowCards.length > 0) {
        comment += ` ${yellowCards.length} sarı kart gösterildi.`
      }

      if (redCards.length > 0) {
        comment += ` ${redCards.map((player) => player.player).join(", ")} kırmızı kart gördü, takımı ${redCards[0].team === homeTeam ? awayTeam : homeTeam} karşısında sayıca eksik durumda.`
      }
    }

    return comment
  }

  // Maç devam ediyor
  let comment = ""

  // Skor durumuna göre yorum
  if (homeScore > awayScore && homeScore - awayScore >= 2) {
    comment = `${matchMinute}. dakikada ${homeTeam} sahada ${homeScore}-${awayScore} üstün durumda. ${awayTeam} skoru yakalamakta zorlanıyor.`
  } else if (awayScore > homeScore && awayScore - homeScore >= 2) {
    comment = `${matchMinute}. dakikada ${awayTeam} deplasmanda ${awayScore}-${homeScore} öne geçti. ${homeTeam}'in daha fazla risk alması gerekiyor.`
  } else if (homeScore === awayScore && totalGoals >= 2) {
    comment = `${matchMinute}. dakikada skor ${homeScore}-${awayScore}. İki takım da güçlü performans sergiliyor, sonuç belirsiz.`
  } else if (totalGoals >= 4) {
    comment = `${matchMinute}. dakikada yüksek skorlu bir maç izliyoruz: ${homeScore}-${awayScore}. 3.5 Üst bahsi kazandı.`
  } else if (totalGoals === 0 && matchMinute > 60) {
    comment = `${matchMinute}. dakikada henüz gol yok. Savunmaların öne çıktığı bir maç, 2.5 Alt olasılığı yüksek.`
  } else if (homeScore > 0 && awayScore > 0) {
    comment = `${matchMinute}. dakikada her iki takım da gol buldu (${homeScore}-${awayScore}), KG Var bahsi kazandı!`
  } else if (matchMinute > 75 && scoreDiff === 0) {
    comment = `Maçın son dakikalarında skor ${homeScore}-${awayScore}. Beraberlik bozulabilir, dikkat!`
  } else if (matchMinute > 75 && scoreDiff === 1) {
    const leadingTeam = homeScore > awayScore ? homeTeam : awayTeam
    const trailingTeam = homeScore > awayScore ? awayTeam : homeTeam
    comment = `${matchMinute}. dakikada ${leadingTeam} ${scoreDiff} farkla önde. ${trailingTeam} son dakikalarda eşitlik için baskı yapıyor.`
  } else {
    comment = `${matchMinute}. dakikada skor ${homeScore}-${awayScore}. Maç devam ediyor, tahminler canlı olarak güncelleniyor.`
  }

  // Son gol
  if (goalScorers.length > 0) {
    const lastGoal = goalScorers[goalScorers.length - 1]
    comment += ` Son golü ${lastGoal.minute}. dakikada ${lastGoal.player} (${lastGoal.team}) kaydetti.`
  }

  // Kart gören oyuncular
  if (cardPlayers.length > 0) {
    const yellowCards = cardPlayers.filter((player) => player.cardType === "yellow card")
    const redCards = cardPlayers.filter((player) => player.cardType === "red card")

    if (redCards.length > 0) {
      const lastRedCard = redCards[redCards.length - 1]
      comment += ` ${lastRedCard.player}, ${lastRedCard.minute}. dakikada kırmızı kart gördü ve ${lastRedCard.team} sayıca eksik oynuyor.`
    } else if (yellowCards.length > 0) {
      if (yellowCards.length >= 3) {
        comment += ` Maçta şu ana kadar ${yellowCards.length} sarı kart gösterildi, sert bir mücadele yaşanıyor.`
      } else {
        const lastYellowCard = yellowCards[yellowCards.length - 1]
        comment += ` ${lastYellowCard.player} (${lastYellowCard.team}), ${lastYellowCard.minute}. dakikada sarı kart gördü.`
      }
    }
  }

  return comment
}
