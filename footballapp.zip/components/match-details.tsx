"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MatchStatistics } from "./match-statistics"
import { MatchSquad } from "./match-squad"
import { H2HAnalysis } from "./h2h-analysis"
import { LastFiveMatchAnalysis } from "./last-five-match-analysis"
import { MatchStarPlayers } from "./match-star-players"
import { getTeamLastMatches } from "@/lib/football-api"
import { Loader2 } from "lucide-react"

interface MatchDetailsProps {
  matchId: string
  homeTeam: string
  awayTeam: string
  homeTeamId: string
  awayTeamId: string
  isLive?: boolean
}

export function MatchDetails({
  matchId,
  homeTeam,
  awayTeam,
  homeTeamId,
  awayTeamId,
  isLive = false,
}: MatchDetailsProps) {
  const [homeLastMatches, setHomeLastMatches] = useState<any[]>([])
  const [awayLastMatches, setAwayLastMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLastMatches = async () => {
      setLoading(true)
      try {
        const [homeMatches, awayMatches] = await Promise.all([
          getTeamLastMatches(homeTeamId, 5),
          getTeamLastMatches(awayTeamId, 5),
        ])

        if (Array.isArray(homeMatches)) {
          setHomeLastMatches(homeMatches)
        }

        if (Array.isArray(awayMatches)) {
          setAwayLastMatches(awayMatches)
        }
      } catch (error) {
        console.error("Error fetching last matches:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchLastMatches()
  }, [homeTeamId, awayTeamId])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <Loader2 className="w-6 h-6 animate-spin text-green-500 mb-2" />
        <p className="text-xs text-slate-400">Maç detayları yükleniyor...</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="statistics" className="w-full">
        <TabsList className="grid grid-cols-5 h-auto">
          <TabsTrigger value="statistics" className="text-[10px] py-1 px-2">
            İstatistikler
          </TabsTrigger>
          <TabsTrigger value="squad" className="text-[10px] py-1 px-2">
            Kadro
          </TabsTrigger>
          <TabsTrigger value="h2h" className="text-[10px] py-1 px-2">
            H2H
          </TabsTrigger>
          <TabsTrigger value="last5" className="text-[10px] py-1 px-2">
            Son 5 Maç
          </TabsTrigger>
          <TabsTrigger value="stars" className="text-[10px] py-1 px-2">
            Yıldızlar
          </TabsTrigger>
        </TabsList>

        <TabsContent value="statistics" className="mt-2">
          <MatchStatistics matchId={matchId} homeTeam={homeTeam} awayTeam={awayTeam} isLive={isLive} />
        </TabsContent>

        <TabsContent value="squad" className="mt-2">
          <MatchSquad
            matchId={matchId}
            homeTeam={homeTeam}
            awayTeam={awayTeam}
            homeTeamId={homeTeamId}
            awayTeamId={awayTeamId}
            isLive={isLive}
          />
        </TabsContent>

        <TabsContent value="h2h" className="mt-2">
          <H2HAnalysis
            firstTeamId={homeTeamId}
            secondTeamId={awayTeamId}
            firstTeamName={homeTeam}
            secondTeamName={awayTeam}
          />
        </TabsContent>

        <TabsContent value="last5" className="mt-2">
          <div className="grid grid-cols-1 gap-3">
            <LastFiveMatchAnalysis teamId={homeTeamId} teamName={homeTeam} matches={homeLastMatches} />
            <LastFiveMatchAnalysis teamId={awayTeamId} teamName={awayTeam} matches={awayLastMatches} />
          </div>
        </TabsContent>

        <TabsContent value="stars" className="mt-2">
          <MatchStarPlayers homeTeam={homeTeam} awayTeam={awayTeam} homeTeamId={homeTeamId} awayTeamId={awayTeamId} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
