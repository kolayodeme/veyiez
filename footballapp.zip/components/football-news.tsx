"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTranslation } from "./language-provider"
import { Loader2, Newspaper, MessageCircle, ThumbsUp, ExternalLink, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface NewsItem {
  id: string
  title: string
  summary: string
  content: string
  imageUrl?: string
  source: string
  publishedAt: string
  category: "transfer" | "match" | "injury" | "general"
  likes: number
  comments: number
}

export function FootballNews() {
  const { t } = useTranslation()
  const [loading, setLoading] = useState(true)
  const [news, setNews] = useState<NewsItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  useEffect(() => {
    // In a real app, we would fetch news from an API
    // For now, generate mock data
    const generateMockNews = () => {
      const categories: ("transfer" | "match" | "injury" | "general")[] = ["transfer", "match", "injury", "general"]

      const mockTitles = [
        "Fenerbahçe'den büyük transfer hamlesi!",
        "Galatasaray derbide son dakika galibiyeti aldı",
        "Beşiktaş'ın yıldızı 3 hafta sahalardan uzak kalacak",
        "Trabzonspor'dan Avrupa yolunda kritik galibiyet",
        "Süper Lig'de şampiyonluk yarışı kızışıyor",
        "Milli Takım kadrosu açıklandı",
        "Yeni sezon fikstürü belli oldu",
        "TFF'den hakemler için yeni karar",
        "Avrupa Ligleri'nde haftanın maçları",
        "VAR sisteminde büyük değişiklik",
      ]

      return Array(10)
        .fill(0)
        .map((_, i) => {
          const category = categories[Math.floor(Math.random() * categories.length)]
          const title = mockTitles[i]
          const timeAgo = Math.floor(Math.random() * 24)

          return {
            id: `news-${i}`,
            title,
            summary: `${title} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.`,
            content:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Mauris at velit vel neque iaculis aliquet. Fusce id magna vel metus convallis auctor. Vivamus euismod magna vel turpis venenatis, eget varius justo volutpat.",
            imageUrl: `/placeholder.svg?height=200&width=400&text=Futbol+Haberi`,
            source: ["TRT Spor", "Fanatik", "Sporx", "A Spor", "NTV Spor"][Math.floor(Math.random() * 5)],
            publishedAt: `${timeAgo} saat önce`,
            category,
            likes: Math.floor(Math.random() * 500),
            comments: Math.floor(Math.random() * 100),
          }
        })
    }

    setLoading(true)
    // Simulate API delay
    setTimeout(() => {
      setNews(generateMockNews())
      setLoading(false)
    }, 1000)
  }, [])

  const filteredNews = selectedCategory === "all" ? news : news.filter((item) => item.category === selectedCategory)

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "transfer":
        return <Badge className="bg-green-600 text-white">Transfer</Badge>
      case "match":
        return <Badge className="bg-blue-600 text-white">Maç</Badge>
      case "injury":
        return <Badge className="bg-red-600 text-white">Sakatlık</Badge>
      default:
        return <Badge className="bg-yellow-600 text-white">Genel</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <Loader2 className="w-6 h-6 animate-spin text-green-500 mb-2" />
        <p className="text-xs text-green-400">Haberler yükleniyor...</p>
      </div>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=400')] opacity-5"></div>
      <CardHeader className="p-3 relative z-10">
        <CardTitle className="text-base text-white flex items-center">
          <Newspaper className="w-4 h-4 mr-2 text-green-400" />
          <span>Futbol Haberleri</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 relative z-10">
        <Tabs defaultValue="all" value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="w-full bg-green-900/30 rounded-none">
            <TabsTrigger
              value="all"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Tümü
            </TabsTrigger>
            <TabsTrigger
              value="transfer"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Transfer
            </TabsTrigger>
            <TabsTrigger
              value="match"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Maçlar
            </TabsTrigger>
            <TabsTrigger
              value="injury"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Sakatlıklar
            </TabsTrigger>
          </TabsList>

          <div className="p-3 space-y-3">
            {filteredNews.length === 0 ? (
              <p className="text-center text-sm text-slate-400">Bu kategoride haber bulunamadı.</p>
            ) : (
              filteredNews.map((item) => (
                <div key={item.id} className="bg-green-900/20 rounded-lg border border-green-700/30 overflow-hidden">
                  {item.imageUrl && (
                    <div className="h-40 overflow-hidden">
                      <img
                        src={item.imageUrl || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="p-3">
                    <div className="flex items-center justify-between mb-2">
                      {getCategoryBadge(item.category)}
                      <div className="flex items-center text-xs text-slate-400">
                        <Clock className="w-3 h-3 mr-1" />
                        {item.publishedAt}
                      </div>
                    </div>
                    <h3 className="text-sm font-bold text-green-400 mb-1">{item.title}</h3>
                    <p className="text-xs text-slate-300 mb-3">{item.summary}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center text-xs text-slate-400">
                          <ThumbsUp className="w-3 h-3 mr-1" />
                          {item.likes}
                        </div>
                        <div className="flex items-center text-xs text-slate-400">
                          <MessageCircle className="w-3 h-3 mr-1" />
                          {item.comments}
                        </div>
                      </div>
                      <Button size="sm" variant="ghost" className="text-xs text-green-400 p-0 h-auto">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Devamını Oku
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  )
}
