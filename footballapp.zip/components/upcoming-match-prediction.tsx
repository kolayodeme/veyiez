"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useTranslation } from "./language-provider"
import { useEffect, useState } from "react"
import { getH2HMatches, getTeamLastMatches } from "@/lib/api"
import { Loader2, Sparkles } from "lucide-react"

interface UpcomingMatchPredictionProps {
  homeTeam: string
  awayTeam: string
  homeTeamId: string
  awayTeamId: string
}

export function UpcomingMatchPrediction({ homeTeam, awayTeam, homeTeamId, awayTeamId }: UpcomingMatchPredictionProps) {
  const { t } = useTranslation()
  const [predictionComment, setPredictionComment] = useState("")
  const [loading, setLoading] = useState(true)
  const [predictions, setPredictions] = useState({
    homeWinProb: 0,
    drawProb: 0,
    awayWinProb: 0,
    over1_5Prob: 0,
    over2_5Prob: 0,
    over3_5Prob: 0,
    bttsProb: 0,
  })

  useEffect(() => {
    const fetchPredictionData = async () => {
      setLoading(true)
      try {
        // Fetch H2H data and last matches for both teams
        const [h2hData, homeLastMatches, awayLastMatches] = await Promise.all([
          getH2HMatches(homeTeamId, awayTeamId),
          getTeamLastMatches(homeTeamId, 5),
          getTeamLastMatches(awayTeamId, 5),
        ])

        // Calculate prediction probabilities based on real data
        const predictionData = calculatePredictions(h2hData, homeLastMatches, awayLastMatches)
        setPredictions(predictionData)

        // Generate prediction comment
        const comment = generatePredictionComment(predictionData, homeTeam, awayTeam)
        setPredictionComment(comment)
      } catch (error) {
        console.error("Error fetching prediction data:", error)
        // Use fallback predictions
        const fallbackPredictions = generateFallbackPredictions()
        setPredictions(fallbackPredictions)
        setPredictionComment(generatePredictionComment(fallbackPredictions, homeTeam, awayTeam))
      } finally {
        setLoading(false)
      }
    }

    fetchPredictionData()
  }, [homeTeam, awayTeam, homeTeamId, awayTeamId])

  const calculatePredictions = (h2hData: any, homeLastMatches: any[], awayLastMatches: any[]) => {
    // Initialize with base probabilities
    let homeWinProb = 40 // Home advantage
    let drawProb = 30
    let awayWinProb = 30
    let over1_5Prob = 70
    let over2_5Prob = 50
    let over3_5Prob = 30
    let bttsProb = 55

    // Process H2H data if available
    if (h2hData && h2hData.firstTeam_VS_secondTeam && Array.isArray(h2hData.firstTeam_VS_secondTeam)) {
      const h2hMatches = h2hData.firstTeam_VS_secondTeam

      if (h2hMatches.length > 0) {
        let homeWins = 0
        let draws = 0
        let awayWins = 0
        let totalGoals = 0
        let bttsCount = 0

        h2hMatches.forEach((match) => {
          const homeScore = Number.parseInt(match.match_hometeam_score) || 0
          const awayScore = Number.parseInt(match.match_awayteam_score) || 0

          totalGoals += homeScore + awayScore

          if (homeScore > 0 && awayScore > 0) {
            bttsCount++
          }

          if (homeScore === awayScore) {
            draws++
          } else if (
            (match.match_hometeam_id === homeTeamId && homeScore > awayScore) ||
            (match.match_awayteam_id === homeTeamId && awayScore > homeScore)
          ) {
            homeWins++
          } else {
            awayWins++
          }
        })

        const totalMatches = h2hMatches.length

        if (totalMatches > 0) {
          // Adjust probabilities based on H2H history
          homeWinProb = Math.round((homeWins / totalMatches) * 100)
          drawProb = Math.round((draws / totalMatches) * 100)
          awayWinProb = Math.round((awayWins / totalMatches) * 100)

          // Ensure probabilities sum to 100%
          const total = homeWinProb + drawProb + awayWinProb
          if (total !== 100) {
            const factor = 100 / total
            homeWinProb = Math.round(homeWinProb * factor)
            drawProb = Math.round(drawProb * factor)
            awayWinProb = 100 - homeWinProb - drawProb
          }

          // Calculate over/under probabilities
          const avgGoals = totalGoals / totalMatches
          over1_5Prob = avgGoals > 1.5 ? 70 + Math.round((avgGoals - 1.5) * 10) : 70 - Math.round((1.5 - avgGoals) * 10)
          over2_5Prob = avgGoals > 2.5 ? 50 + Math.round((avgGoals - 2.5) * 10) : 50 - Math.round((2.5 - avgGoals) * 10)
          over3_5Prob = avgGoals > 3.5 ? 30 + Math.round((avgGoals - 3.5) * 10) : 30 - Math.round((3.5 - avgGoals) * 10)

          // Calculate BTTS probability
          bttsProb = Math.round((bttsCount / totalMatches) * 100)
        }
      }
    }

    // Process last matches data to adjust probabilities
    if (Array.isArray(homeLastMatches) && Array.isArray(awayLastMatches)) {
      const homeForm = calculateTeamForm(homeLastMatches, homeTeamId)
      const awayForm = calculateTeamForm(awayLastMatches, awayTeamId)

      // Adjust win probabilities based on recent form
      const formDifference = homeForm - awayForm
      homeWinProb += Math.round(formDifference * 0.5)
      awayWinProb -= Math.round(formDifference * 0.5)

      // Ensure probabilities are within bounds
      homeWinProb = Math.max(10, Math.min(80, homeWinProb))
      awayWinProb = Math.max(10, Math.min(80, awayWinProb))
      drawProb = 100 - homeWinProb - awayWinProb

      // Adjust over/under probabilities based on recent scoring
      const homeGoalsScored = calculateTeamGoalsScored(homeLastMatches, homeTeamId)
      const homeGoalsConceded = calculateTeamGoalsConceded(homeLastMatches, homeTeamId)
      const awayGoalsScored = calculateTeamGoalsScored(awayLastMatches, awayTeamId)
      const awayGoalsConceded = calculateTeamGoalsConceded(awayLastMatches, awayTeamId)

      const expectedGoals = (homeGoalsScored + awayGoalsConceded + awayGoalsScored + homeGoalsConceded) / 4

      over1_5Prob =
        expectedGoals > 1.5 ? 70 + Math.round((expectedGoals - 1.5) * 10) : 70 - Math.round((1.5 - expectedGoals) * 10)
      over2_5Prob =
        expectedGoals > 2.5 ? 50 + Math.round((expectedGoals - 2.5) * 10) : 50 - Math.round((2.5 - expectedGoals) * 10)
      over3_5Prob =
        expectedGoals > 3.5 ? 30 + Math.round((expectedGoals - 3.5) * 10) : 30 - Math.round((3.5 - expectedGoals) * 10)

      // Adjust BTTS probability
      const homeScoringRate = calculateTeamScoringRate(homeLastMatches, homeTeamId)
      const awayScoringRate = calculateTeamScoringRate(awayLastMatches, awayTeamId)

      bttsProb = Math.round(homeScoringRate * awayScoringRate * 100)
    }

    // Ensure all probabilities are within bounds
    over1_5Prob = Math.max(10, Math.min(95, over1_5Prob))
    over2_5Prob = Math.max(10, Math.min(90, over2_5Prob))
    over3_5Prob = Math.max(5, Math.min(80, over3_5Prob))
    bttsProb = Math.max(10, Math.min(90, bttsProb))

    return {
      homeWinProb,
      drawProb,
      awayWinProb,
      over1_5Prob,
      over2_5Prob,
      over3_5Prob,
      bttsProb,
    }
  }

  // Helper function to calculate team form (0-100)
  const calculateTeamForm = (matches: any[], teamId: string): number => {
    if (!Array.isArray(matches) || matches.length === 0) return 50

    let points = 0
    const maxPoints = matches.length * 3

    matches.forEach((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score) || 0
      const awayScore = Number.parseInt(match.match_awayteam_score) || 0

      if (homeScore === awayScore) {
        points += 1 // Draw = 1 point
      } else if ((isHome && homeScore > awayScore) || (!isHome && awayScore > homeScore)) {
        points += 3 // Win = 3 points
      }
    })

    return Math.round((points / maxPoints) * 100)
  }

  // Helper function to calculate team's average goals scored
  const calculateTeamGoalsScored = (matches: any[], teamId: string): number => {
    if (!Array.isArray(matches) || matches.length === 0) return 1.5

    let totalGoals = 0

    matches.forEach((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score) || 0
      const awayScore = Number.parseInt(match.match_awayteam_score) || 0

      totalGoals += isHome ? homeScore : awayScore
    })

    return totalGoals / matches.length
  }

  // Helper function to calculate team's average goals conceded
  const calculateTeamGoalsConceded = (matches: any[], teamId: string): number => {
    if (!Array.isArray(matches) || matches.length === 0) return 1.5

    let totalGoals = 0

    matches.forEach((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score) || 0
      const awayScore = Number.parseInt(match.match_awayteam_score) || 0

      totalGoals += isHome ? awayScore : homeScore
    })

    return totalGoals / matches.length
  }

  // Helper function to calculate team's scoring rate (0-1)
  const calculateTeamScoringRate = (matches: any[], teamId: string): number => {
    if (!Array.isArray(matches) || matches.length === 0) return 0.7

    let scoredCount = 0

    matches.forEach((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score) || 0
      const awayScore = Number.parseInt(match.match_awayteam_score) || 0

      if ((isHome && homeScore > 0) || (!isHome && awayScore > 0)) {
        scoredCount++
      }
    })

    return scoredCount / matches.length
  }

  // Generate fallback predictions if API data is unavailable
  const generateFallbackPredictions = () => {
    // Home advantage
    const homeWinProb = 35 + Math.floor(Math.random() * 30)
    const drawProb = 20 + Math.floor(Math.random() * 20)
    const awayWinProb = 100 - homeWinProb - drawProb

    // Over/Under probabilities
    const over1_5Prob = 70 + Math.floor(Math.random() * 20)
    const over2_5Prob = 45 + Math.floor(Math.random() * 30)
    const over3_5Prob = 25 + Math.floor(Math.random() * 25)

    // BTTS probability
    const bttsProb = 50 + Math.floor(Math.random() * 30)

    return {
      homeWinProb,
      drawProb,
      awayWinProb,
      over1_5Prob,
      over2_5Prob,
      over3_5Prob,
      bttsProb,
    }
  }

  // Generate prediction comment based on probabilities
  const generatePredictionComment = (
    predictionData: {
      homeWinProb: number
      drawProb: number
      awayWinProb: number
      over1_5Prob: number
      over2_5Prob: number
      over3_5Prob: number
      bttsProb: number
    },
    homeTeamName: string,
    awayTeamName: string,
  ) => {
    const { homeWinProb, drawProb, awayWinProb, over2_5Prob, bttsProb } = predictionData

    let comment = ""

    // Determine match winner prediction
    if (homeWinProb > awayWinProb + 15) {
      comment = `${homeTeamName} bu maçın favorisi görünüyor. %${homeWinProb} ihtimalle kazanmaları bekleniyor.`
    } else if (awayWinProb > homeWinProb + 15) {
      comment = `${awayTeamName} deplasmanda avantajlı görünüyor. %${awayWinProb} ihtimalle kazanmaları bekleniyor.`
    } else {
      comment = `İki takım da birbirine denk görünüyor. Beraberlik %${drawProb} ihtimalle en olası sonuç.`
    }

    // Add goals prediction
    if (over2_5Prob > 60) {
      comment += ` Maçta 2.5 üst gol bekleniyor (%${over2_5Prob} ihtimal).`
    } else {
      comment += ` Maçta 2.5 alt gol bekleniyor (%${100 - over2_5Prob} ihtimal).`
    }

    // Add BTTS prediction
    if (bttsProb > 60) {
      comment += ` Karşılıklı gol olasılığı yüksek (%${bttsProb}).`
    } else {
      comment += ` Karşılıklı gol olasılığı düşük (%${bttsProb}).`
    }

    return comment
  }

  if (loading) {
    return (
      <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 overflow-hidden relative">
        <CardContent className="p-4 flex justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-green-500" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-700/30 overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=400')] opacity-5"></div>
      <CardHeader className="p-3 relative z-10">
        <CardTitle className="text-base text-white flex items-center">
          <Sparkles className="w-4 h-4 mr-2 text-yellow-400" />
          <span className="text-green-400">{t("matchPredictions")}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 space-y-4 relative z-10">
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("matchWinner")}</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-green-400">{homeTeam}</span>
              <span>{Math.round(predictions.homeWinProb)}%</span>
            </div>
            <Progress
              value={predictions.homeWinProb}
              className="h-1.5 bg-slate-700 stat-bar"
              indicatorClassName="bg-green-500 glow-green stat-bar-home"
            />

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>{t("draw")}</span>
              <span>{Math.round(predictions.drawProb)}%</span>
            </div>
            <Progress
              value={predictions.drawProb}
              className="h-1.5 bg-slate-700 stat-bar"
              indicatorClassName="bg-yellow-500 glow-yellow"
            />

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-yellow-400">{awayTeam}</span>
              <span>{Math.round(predictions.awayWinProb)}%</span>
            </div>
            <Progress
              value={predictions.awayWinProb}
              className="h-1.5 bg-slate-700 stat-bar"
              indicatorClassName="bg-yellow-500 glow-yellow stat-bar-away"
            />
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("overUnder")}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>O 1.5</span>
                <span>{Math.round(predictions.over1_5Prob)}%</span>
              </div>
              <Progress
                value={predictions.over1_5Prob}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>U 1.5</span>
                <span>{Math.round(100 - predictions.over1_5Prob)}%</span>
              </div>
              <Progress
                value={100 - predictions.over1_5Prob}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>O 2.5</span>
                <span>{Math.round(predictions.over2_5Prob)}%</span>
              </div>
              <Progress
                value={predictions.over2_5Prob}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>U 2.5</span>
                <span>{Math.round(100 - predictions.over2_5Prob)}%</span>
              </div>
              <Progress
                value={100 - predictions.over2_5Prob}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-amber-500 glow-yellow"
              />
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-green-400 border-b border-green-700/30 pb-1">{t("btts")}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>{t("yes")}</span>
                <span>{Math.round(predictions.bttsProb)}%</span>
              </div>
              <Progress
                value={predictions.bttsProb}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-green-500 glow-green stat-bar-home"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>{t("no")}</span>
                <span>{Math.round(100 - predictions.bttsProb)}%</span>
              </div>
              <Progress
                value={100 - predictions.bttsProb}
                className="h-1.5 bg-slate-700 stat-bar"
                indicatorClassName="bg-green-500 glow-green stat-bar-home"
              />
            </div>
          </div>
        </div>

        {predictionComment && (
          <div className="p-2 mt-3 rounded-lg bg-green-900/20 border border-green-700/30">
            <h3 className="mb-1 text-xs font-medium text-green-400 flex items-center">
              <Sparkles className="w-3 h-3 mr-1" />
              {t("predictionComment")}
            </h3>
            <p className="text-xs text-slate-300">{predictionComment}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
