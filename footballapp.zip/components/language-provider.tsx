"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

// Define the translations
const translations = {
  en: {
    // Navigation
    live: "Live Matches",
    predictions: "Predictions",
    statistics: "Statistics",
    upcoming: "Upcoming",

    // Live match screen
    liveMatches: "Live Matches",
    noLiveMatches: "No live matches at the moment",
    halfTime: "HT",
    fullTime: "FT",
    live: "LIVE",
    goals: "Goals",
    cards: "Cards",
    substitutions: "Substitutions",
    commentary: "Live Commentary",

    // Predictions
    matchPredictions: "Match Predictions",
    overUnder: "Over/Under",
    btts: "Both Teams to Score",
    matchWinner: "Match Winner",
    probability: "Probability",
    predictionComment: "Prediction Comment",

    // Statistics
    lastFiveMatches: "Last 5 Matches",
    goalsPerMatch: "Goals per Match",
    cardsPerMatch: "Cards per Match",
    predictedOutcomes: "Predicted Outcomes",

    // Upcoming matches
    upcomingMatches: "Upcoming Matches",
    filterByTeam: "Filter by Team",
    filterByLeague: "Filter by League",
    filterByCountry: "Filter by Country",
    searchTeams: "Search Teams",

    // General
    loading: "Loading...",
    error: "Error loading data",
    retry: "Retry",
    noData: "No data available",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    language: "Language",
    home: "Home",
    away: "Away",
    date: "Date",
    time: "Time",
    win: "Win",
    draw: "Draw",
    loss: "Loss",
    yes: "Yes",
    no: "No",
    over: "Over",
    under: "Under",
  },
  tr: {
    // Navigation
    live: "Canlı Maçlar",
    predictions: "Tahminler",
    statistics: "İstatistikler",
    upcoming: "Yaklaşan",

    // Live match screen
    liveMatches: "Canlı Maçlar",
    noLiveMatches: "Şu anda canlı maç yok",
    halfTime: "D.A.",
    fullTime: "M.S.",
    live: "CANLI",
    goals: "Goller",
    cards: "Kartlar",
    substitutions: "Değişiklikler",
    commentary: "Canlı Yorum",

    // Predictions
    matchPredictions: "Maç Tahminleri",
    overUnder: "Üst/Alt",
    btts: "İki Takım da Gol Atar",
    matchWinner: "Maç Kazananı",
    probability: "Olasılık",
    predictionComment: "Tahmin Yorumu",

    // Statistics
    lastFiveMatches: "Son 5 Maç",
    goalsPerMatch: "Maç Başına Goller",
    cardsPerMatch: "Maç Başına Kartlar",
    predictedOutcomes: "Tahmin Edilen Sonuçlar",

    // Upcoming matches
    upcomingMatches: "Yaklaşan Maçlar",
    filterByTeam: "Takıma Göre Filtrele",
    filterByLeague: "Lige Göre Filtrele",
    filterByCountry: "Ülkeye Göre Filtrele",
    searchTeams: "Takım Ara",

    // General
    loading: "Yükleniyor...",
    error: "Veri yüklenirken hata oluştu",
    retry: "Tekrar Dene",
    noData: "Veri bulunamadı",
    darkMode: "Karanlık Mod",
    lightMode: "Aydınlık Mod",
    language: "Dil",
    home: "Ev Sahibi",
    away: "Deplasman",
    date: "Tarih",
    time: "Saat",
    win: "Galibiyet",
    draw: "Beraberlik",
    loss: "Mağlubiyet",
    yes: "Evet",
    no: "Hayır",
    over: "Üst",
    under: "Alt",
  },
}

type Language = "en" | "tr"
type TranslationKey = keyof typeof translations.en

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: TranslationKey) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  // Load language preference from localStorage on client side
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "en" || savedLanguage === "tr")) {
      setLanguage(savedLanguage)
    }
  }, [])

  // Save language preference to localStorage
  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useTranslation() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useTranslation must be used within a LanguageProvider")
  }
  return context
}
