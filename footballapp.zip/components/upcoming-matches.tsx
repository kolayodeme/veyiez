"use client"

import { useState, useEffect, useRef } from "react"
import { getUpcomingMatches, getCountries, getLeagues, getTeamLastMatches, getMatchLineups } from "@/lib/football-api"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertCircle,
  RefreshCw,
  Search,
  Loader2,
  Calendar,
  BarChart2,
  Users,
  Star,
  StickerIcon as Stadium,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTranslation } from "./language-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { format, isToday, isTomorrow, addDays, isWithinInterval } from "date-fns"
import { tr } from "date-fns/locale"
import { H2HAnalysis } from "./h2h-analysis"
import { LastFiveMatchAnalysis } from "./last-five-match-analysis"
import { UpcomingMatchPrediction } from "./upcoming-match-prediction"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MatchStarPlayers } from "./match-star-players"
import { TeamLineup } from "./team-lineup"
import { Progress } from "@/components/ui/progress"

interface Match {
  match_id: string
  match_date: string
  match_time: string
  match_hometeam_name: string
  match_awayteam_name: string
  match_hometeam_id: string
  match_awayteam_id: string
  team_home_badge: string
  team_away_badge: string
  league_name: string
  league_logo?: string
  country_name: string
  country_logo?: string
  match_stadium?: string
  league_id?: string
}

interface Country {
  country_id: string
  country_name: string
  country_logo?: string
}

interface League {
  league_id: string
  league_name: string
  league_logo?: string
  country_id: string
}

export function UpcomingMatches() {
  const [matches, setMatches] = useState<Match[]>([])
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [countries, setCountries] = useState<Country[]>([])
  const [leagues, setLeagues] = useState<League[]>([])
  const [selectedCountry, setSelectedCountry] = useState<string>("all-countries")
  const [selectedLeague, setSelectedLeague] = useState<string>("all-leagues")
  const [searchTerm, setSearchTerm] = useState<string>("")
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("h2h")
  const [selectedDate, setSelectedDate] = useState<string>("today")
  const { t } = useTranslation()
  const selectedMatchRef = useRef<HTMLDivElement>(null)
  const [homeLastMatches, setHomeLastMatches] = useState<any[]>([])
  const [awayLastMatches, setAwayLastMatches] = useState<any[]>([])
  const [lineupData, setLineupData] = useState<any>(null)
  const [isLoadingDetails, setIsLoadingDetails] = useState<boolean>(false)

  // Get today's date and 7 days from now
  const today = new Date()
  const nextWeek = new Date(today)
  nextWeek.setDate(today.getDate() + 7)

  const formatDateForApi = (date: Date) => {
    return format(date, "yyyy-MM-dd")
  }

  const formatDateForDisplay = (dateString: string) => {
    const date = new Date(dateString)
    if (isToday(date)) {
      return "Bugün"
    } else if (isTomorrow(date)) {
      return "Yarın"
    } else {
      return format(date, "d MMMM EEEE", { locale: tr })
    }
  }

  const fetchUpcomingMatches = async () => {
    try {
      setLoading(true)
      setError(null)
      setLoadingProgress(0)

      // Simüle edilmiş yükleme ilerlemesi
      const progressInterval = setInterval(() => {
        setLoadingProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return prev
          }
          return prev + 10
        })
      }, 300)

      // API'den veri çekme
      const data = await getUpcomingMatches(formatDateForApi(today), formatDateForApi(nextWeek))

      if (Array.isArray(data) && data.length > 0) {
        setMatches(data)
        setFilteredMatches(data)
      } else {
        setError("Yaklaşan maç verisi bulunamadı.")
      }

      setLoadingProgress(100)
      clearInterval(progressInterval)
    } catch (err) {
      console.error("Error fetching upcoming matches:", err)
      setError(t("error"))
      setLoadingProgress(100)
    } finally {
      setTimeout(() => {
        setLoading(false)
      }, 500) // Yükleme çubuğunun tamamlandığını görmek için kısa bir gecikme
    }
  }

  const fetchCountries = async () => {
    try {
      const data = await getCountries()
      if (Array.isArray(data)) {
        setCountries(data)
      }
    } catch (err) {
      console.error("Error fetching countries:", err)
    }
  }

  const fetchLeagues = async (countryId?: string) => {
    try {
      const data = await getLeagues(countryId)
      if (Array.isArray(data)) {
        setLeagues(data)
      }
    } catch (err) {
      console.error("Error fetching leagues:", err)
    }
  }

  const fetchMatchDetails = async (matchId: string, homeTeamId: string, awayTeamId: string) => {
    setIsLoadingDetails(true)
    try {
      // Fetch team last matches
      const [homeMatches, awayMatches, lineups] = await Promise.all([
        getTeamLastMatches(homeTeamId, 5),
        getTeamLastMatches(awayTeamId, 5),
        getMatchLineups(matchId),
      ])

      if (Array.isArray(homeMatches)) {
        setHomeLastMatches(homeMatches)
      }

      if (Array.isArray(awayMatches)) {
        setAwayLastMatches(awayMatches)
      }

      if (lineups) {
        setLineupData(lineups)
      }
    } catch (error) {
      console.error("Error fetching match details:", error)
    } finally {
      setIsLoadingDetails(false)
    }
  }

  useEffect(() => {
    fetchUpcomingMatches()
    fetchCountries()
  }, [])

  useEffect(() => {
    if (selectedCountry && selectedCountry !== "all-countries") {
      fetchLeagues(selectedCountry)
      setSelectedLeague("all-leagues")
    } else {
      fetchLeagues()
    }
  }, [selectedCountry])

  useEffect(() => {
    let filtered = [...matches]

    // Filter by date
    if (selectedDate === "today") {
      filtered = filtered.filter((match) => isToday(new Date(match.match_date)))
    } else if (selectedDate === "tomorrow") {
      filtered = filtered.filter((match) => isTomorrow(new Date(match.match_date)))
    } else if (selectedDate === "week") {
      filtered = filtered.filter((match) =>
        isWithinInterval(new Date(match.match_date), {
          start: today,
          end: addDays(today, 7),
        }),
      )
    }

    // Filter by country
    if (selectedCountry && selectedCountry !== "all-countries") {
      filtered = filtered.filter(
        (match) => match.country_name === countries.find((c) => c.country_id === selectedCountry)?.country_name,
      )
    }

    // Filter by league
    if (selectedLeague && selectedLeague !== "all-leagues") {
      filtered = filtered.filter(
        (match) => match.league_name === leagues.find((l) => l.league_id === selectedLeague)?.league_name,
      )
    }

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (match) =>
          match.match_hometeam_name.toLowerCase().includes(term) ||
          match.match_awayteam_name.toLowerCase().includes(term),
      )
    }

    setFilteredMatches(filtered)
  }, [selectedDate, selectedCountry, selectedLeague, searchTerm, matches])

  const handleMatchClick = (matchId: string, homeTeamId: string, awayTeamId: string) => {
    if (selectedMatchId === matchId) {
      setSelectedMatchId(null)
      setHomeLastMatches([])
      setAwayLastMatches([])
      setLineupData(null)
    } else {
      setSelectedMatchId(matchId)
      setActiveTab("h2h")
      fetchMatchDetails(matchId, homeTeamId, awayTeamId)
    }
  }

  // Scroll to selected match when data refreshes
  useEffect(() => {
    if (selectedMatchId && selectedMatchRef.current) {
      setTimeout(() => {
        selectedMatchRef.current?.scrollIntoView({ behavior: "smooth", block: "center" })
      }, 100)
    }
  }, [filteredMatches, selectedMatchId])

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2">
          <Skeleton className="w-full h-10" />
          <Skeleton className="w-full h-10" />
          <Skeleton className="w-full h-10" />
        </div>

        <div className="flex flex-col items-center justify-center p-8">
          <div className="w-full max-w-xs mb-4">
            <Progress value={loadingProgress} className="h-2" />
          </div>
          <Loader2 className="w-8 h-8 animate-spin text-green-500" />
          <p className="mt-2 text-sm text-green-400">Yaklaşan maçlar yükleniyor... {loadingProgress}%</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" size="sm" className="mt-2" onClick={fetchUpcomingMatches}>
          <RefreshCw className="w-4 h-4 mr-2" />
          {t("retry")}
        </Button>
      </Alert>
    )
  }

  // Group matches by date
  const matchesByDate = filteredMatches.reduce(
    (acc, match) => {
      if (!acc[match.match_date]) {
        acc[match.match_date] = []
      }
      acc[match.match_date].push(match)
      return acc
    },
    {} as Record<string, Match[]>,
  )

  const selectedMatch = matches.find((match) => match.match_id === selectedMatchId)

  return (
    <div className="space-y-3 max-w-md mx-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-green-400 glow-green">{t("upcomingMatches")}</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={fetchUpcomingMatches}
          className="flex items-center bg-green-900/30 border-green-700/50 text-green-400 hover:bg-green-800/50"
        >
          <RefreshCw className="w-3 h-3 mr-1" />
          {t("retry")}
        </Button>
      </div>

      {/* Date filter tabs */}
      <div className="mb-3">
        <Tabs defaultValue="today" value={selectedDate} onValueChange={setSelectedDate}>
          <TabsList className="w-full bg-green-900/30 border border-green-700/30">
            <TabsTrigger
              value="today"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              <Calendar className="w-3 h-3 mr-1" />
              Bugün
            </TabsTrigger>
            <TabsTrigger
              value="tomorrow"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Yarın
            </TabsTrigger>
            <TabsTrigger
              value="week"
              className="flex-1 text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
            >
              Bu Hafta
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2">
        <div className="flex-1">
          <Select value={selectedCountry} onValueChange={setSelectedCountry}>
            <SelectTrigger className="text-xs bg-slate-800 border-green-700/30 text-white">
              <SelectValue placeholder={t("filterByCountry")} />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-green-700/30">
              <SelectItem value="all-countries" className="text-xs">
                Tüm Ülkeler
              </SelectItem>
              {countries.map((country) => (
                <SelectItem key={country.country_id} value={country.country_id} className="text-xs">
                  <div className="flex items-center">
                    {country.country_logo && (
                      <img
                        src={country.country_logo || "/placeholder.svg"}
                        alt={country.country_name}
                        className="w-4 h-4 mr-2 rounded-full"
                      />
                    )}
                    {country.country_name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex-1">
          <Select value={selectedLeague} onValueChange={setSelectedLeague}>
            <SelectTrigger className="text-xs bg-slate-800 border-green-700/30 text-white">
              <SelectValue placeholder={t("filterByLeague")} />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-green-700/30">
              <SelectItem value="all-leagues" className="text-xs">
                Tüm Ligler
              </SelectItem>
              {leagues.map((league) => (
                <SelectItem key={league.league_id} value={league.league_id} className="text-xs">
                  <div className="flex items-center">
                    {league.league_logo && (
                      <img
                        src={league.league_logo || "/placeholder.svg"}
                        alt={league.league_name}
                        className="w-4 h-4 mr-2 rounded-full"
                      />
                    )}
                    {league.league_name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2 top-2 h-3 w-3 text-green-500" />
            <Input
              placeholder={t("searchTeams")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-7 text-xs h-8 bg-slate-800 border-green-700/30 text-white"
            />
          </div>
        </div>
      </div>

      {Object.keys(matchesByDate).length === 0 ? (
        <Card className="bg-slate-800 border-green-700/30">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-green-400">{t("noData")}</p>
          </CardContent>
        </Card>
      ) : (
        Object.entries(matchesByDate)
          .sort(([dateA], [dateB]) => new Date(dateA).getTime() - new Date(dateB).getTime())
          .map(([date, dateMatches]) => (
            <div key={date} className="space-y-2">
              <h3 className="text-sm font-medium text-yellow-400 bg-green-900/30 p-2 rounded border border-green-700/30 flex items-center">
                <Calendar className="w-4 h-4 mr-2 text-green-400" />
                {formatDateForDisplay(date)}
                <Badge className="ml-2 bg-green-700 text-white">{dateMatches.length} Maç</Badge>
              </h3>

              <div className="grid grid-cols-1 gap-2">
                {dateMatches.map((match) => (
                  <div
                    key={match.match_id}
                    className="space-y-2"
                    ref={match.match_id === selectedMatchId ? selectedMatchRef : null}
                  >
                    <Card
                      className={`bg-gradient-to-r from-slate-800 to-slate-900 border-green-700/30 hover:border-green-600/50 transition-colors cursor-pointer ${
                        selectedMatchId === match.match_id ? "border-green-500 glow-green" : ""
                      }`}
                      onClick={() => handleMatchClick(match.match_id, match.match_hometeam_id, match.match_awayteam_id)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            {match.league_logo && (
                              <img
                                src={match.league_logo || "/placeholder.svg"}
                                alt={match.league_name}
                                className="w-5 h-5 mr-1 rounded-full"
                              />
                            )}
                            <Badge
                              variant="outline"
                              className="text-[10px] px-1 py-0 border-green-700/30 text-green-400 bg-green-900/20"
                            >
                              {match.league_name}
                            </Badge>
                          </div>
                          <div>
                            <Badge
                              variant="outline"
                              className="text-[10px] px-1 py-0 border-yellow-600/30 text-yellow-400 bg-yellow-900/20"
                            >
                              {match.match_time}
                            </Badge>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
                          <div className="flex items-center space-x-1">
                            <div className="w-6 h-6 overflow-hidden rounded-full bg-slate-700">
                              {match.team_home_badge ? (
                                <img
                                  src={match.team_home_badge || "/placeholder.svg"}
                                  alt={match.match_hometeam_name}
                                  className="object-cover w-full h-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="flex items-center justify-center w-full h-full text-xs font-bold text-white">
                                  {match.match_hometeam_name.substring(0, 1)}
                                </div>
                              )}
                            </div>
                            <span className="text-sm font-medium text-white">{match.match_hometeam_name}</span>
                          </div>

                          <div className="flex items-center justify-center">
                            <span className="text-xs font-medium text-yellow-400">VS</span>
                          </div>

                          <div className="flex items-center space-x-1">
                            <span className="text-sm font-medium text-white">{match.match_awayteam_name}</span>
                            <div className="w-6 h-6 overflow-hidden rounded-full bg-slate-700">
                              {match.team_away_badge ? (
                                <img
                                  src={match.team_away_badge || "/placeholder.svg"}
                                  alt={match.match_awayteam_name}
                                  className="object-cover w-full h-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                                  }}
                                />
                              ) : (
                                <div className="flex items-center justify-center w-full h-full text-xs font-bold text-white">
                                  {match.match_awayteam_name.substring(0, 1)}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {match.match_stadium && (
                          <div className="mt-2 flex items-center justify-center text-xs text-slate-400">
                            <Stadium className="w-3 h-3 mr-1" />
                            <span>{match.match_stadium}</span>
                          </div>
                        )}

                        <div className="mt-3 flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 text-xs bg-green-900/30 border-green-700/30 text-green-400 hover:bg-green-800/50"
                            onClick={() =>
                              handleMatchClick(match.match_id, match.match_hometeam_id, match.match_awayteam_id)
                            }
                          >
                            <BarChart2 className="w-3 h-3 mr-1" />
                            {selectedMatchId === match.match_id ? "Detayları Gizle" : "Analiz Et"}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {selectedMatchId === match.match_id && (
                      <Card className="bg-slate-800 border-green-700/30">
                        <CardContent className="p-3">
                          {isLoadingDetails ? (
                            <div className="flex flex-col items-center justify-center p-4">
                              <Loader2 className="w-6 h-6 animate-spin text-green-500 mb-2" />
                              <p className="text-xs text-green-400">Detaylar yükleniyor...</p>
                            </div>
                          ) : (
                            <Tabs value={activeTab} onValueChange={setActiveTab}>
                              <TabsList className="bg-green-900/30 w-full border border-green-700/30">
                                <TabsTrigger
                                  value="h2h"
                                  className="text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
                                >
                                  <BarChart2 className="w-3 h-3 mr-1" />
                                  H2H Analiz
                                </TabsTrigger>
                                <TabsTrigger
                                  value="last5"
                                  className="text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
                                >
                                  Son 5 Maç
                                </TabsTrigger>
                                <TabsTrigger
                                  value="prediction"
                                  className="text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
                                >
                                  Tahmin
                                </TabsTrigger>
                                <TabsTrigger
                                  value="lineup"
                                  className="text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
                                >
                                  <Users className="w-3 h-3 mr-1" />
                                  Kadro
                                </TabsTrigger>
                                <TabsTrigger
                                  value="stars"
                                  className="text-xs data-[state=active]:bg-green-800/50 data-[state=active]:text-green-400"
                                >
                                  <Star className="w-3 h-3 mr-1" />
                                  Yıldızlar
                                </TabsTrigger>
                              </TabsList>

                              <TabsContent value="h2h" className="mt-3">
                                <H2HAnalysis
                                  firstTeamId={match.match_hometeam_id}
                                  secondTeamId={match.match_awayteam_id}
                                  firstTeamName={match.match_hometeam_name}
                                  secondTeamName={match.match_awayteam_name}
                                />
                              </TabsContent>

                              <TabsContent value="last5" className="mt-3">
                                <div className="grid grid-cols-1 gap-3">
                                  <LastFiveMatchAnalysis
                                    teamId={match.match_hometeam_id}
                                    teamName={match.match_hometeam_name}
                                    matches={homeLastMatches}
                                  />
                                  <LastFiveMatchAnalysis
                                    teamId={match.match_awayteam_id}
                                    teamName={match.match_awayteam_name}
                                    matches={awayLastMatches}
                                  />
                                </div>
                              </TabsContent>

                              <TabsContent value="prediction" className="mt-3">
                                <UpcomingMatchPrediction
                                  homeTeam={match.match_hometeam_name}
                                  awayTeam={match.match_awayteam_name}
                                  homeTeamId={match.match_hometeam_id}
                                  awayTeamId={match.match_awayteam_id}
                                />
                              </TabsContent>

                              <TabsContent value="lineup" className="mt-3">
                                <TeamLineup
                                  homeTeam={match.match_hometeam_name}
                                  awayTeam={match.match_awayteam_name}
                                  lineup={lineupData}
                                />
                              </TabsContent>

                              <TabsContent value="stars" className="mt-3">
                                <MatchStarPlayers
                                  homeTeam={match.match_hometeam_name}
                                  awayTeam={match.match_awayteam_name}
                                  homeTeamId={match.match_hometeam_id}
                                  awayTeamId={match.match_awayteam_id}
                                />
                              </TabsContent>
                            </Tabs>
                          )}
                        </CardContent>
                      </Card>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
      )}
    </div>
  )
}
