import axios from "axios"
import { cacheService } from "./cache-service"

// API anahtarı ve temel URL
const API_KEY = process.env.API_KEY || "683285e9509756c7701996a447e238940bd3bc11b26afb6e4de24994ad49ba22"
const API_BASE_URL = process.env.API_BASE_URL || "https://apiv3.apifootball.com"

// Axios örneği oluştur
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  params: {
    APIkey: API_KEY,
  },
  timeout: 10000, // 10 saniye timeout
})

// Yeniden deneme mantığı ekle
apiClient.interceptors.response.use(undefined, async (error) => {
  const { config, response } = error

  // Sadece ağ hatalarında veya 5xx hatalarında yeniden dene
  if (!response || (response && response.status >= 500)) {
    config._retryCount = config._retryCount || 0

    if (config._retryCount < 3) {
      config._retryCount += 1

      // Üstel geri çekilme
      const delay = 1000 * Math.pow(2, config._retryCount)
      console.log(`API isteği yeniden deneniyor (${config._retryCount}/3) ${delay}ms sonra...`)
      await new Promise((resolve) => setTimeout(resolve, delay))

      return apiClient(config)
    }
  }

  // Hata bilgilerini logla
  console.error("API Hatası:", {
    url: config.url,
    params: config.params,
    status: response?.status,
    statusText: response?.statusText,
    data: response?.data,
  })

  return Promise.reject(error)
})

// API yanıtlarını işle
const handleApiResponse = async (apiCall: Promise<any>, cacheKey: string, cacheDuration: number) => {
  try {
    // Önbellekten veriyi kontrol et
    const cachedData = cacheService.get(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // API'den veriyi çek
    const response = await apiCall
    if (response.data) {
      // Veriyi önbelleğe al
      cacheService.set(cacheKey, response.data, cacheDuration)
      return response.data
    }

    throw new Error("Boş API yanıtı")
  } catch (error) {
    console.error(`API çağrısında hata (${cacheKey}):`, error)
    throw error
  }
}

// Canlı maçları çek
export async function getLiveMatches() {
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_events",
        match_live: "1",
      },
    }),
    "live_matches",
    15 * 1000, // 15 saniye önbellek
  )
}

// Maç detaylarını çek
export async function getMatchDetails(matchId: string) {
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_events",
        match_id: matchId,
      },
    }),
    `match_details_${matchId}`,
    15 * 1000, // 15 saniye önbellek
  )
}

// Maç istatistiklerini çek
export async function getMatchStatistics(matchId: string) {
  try {
    const cacheKey = `match_statistics_${matchId}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    const response = await apiClient.get("", {
      params: {
        action: "get_statistics",
        match_id: matchId,
      },
    })

    // API yanıtını kontrol et
    if (
      !response.data ||
      response.data === "No statistics found" ||
      (Array.isArray(response.data) && response.data.length === 0)
    ) {
      console.log("İstatistik verisi bulunamadı")
      return null
    }

    // Veriyi işle
    let statistics = {}

    if (Array.isArray(response.data)) {
      // İstatistikleri işle
      statistics = response.data.reduce((acc, stat) => {
        if (stat.type && stat.home !== undefined && stat.away !== undefined) {
          acc[stat.type] = {
            home: stat.home,
            away: stat.away,
          }
        }
        return acc
      }, {})
    } else if (typeof response.data === "object") {
      // Tek bir istatistik nesnesi
      Object.entries(response.data).forEach(([key, value]: [string, any]) => {
        if (value && value.home !== undefined && value.away !== undefined) {
          statistics[key] = {
            home: value.home,
            away: value.away,
          }
        }
      })
    }

    // İstatistik yoksa null döndür
    if (Object.keys(statistics).length === 0) {
      console.log("İşlenebilir istatistik verisi bulunamadı")
      return null
    }

    // Önbelleğe al
    cacheService.set(cacheKey, statistics, 15 * 1000) // 15 saniye önbellek
    return statistics
  } catch (error) {
    console.error("İstatistik verisi çekilirken hata:", error)
    throw error
  }
}

// Maç kadrosunu çek
export async function getMatchLineups(matchId: string) {
  try {
    const cacheKey = `match_lineups_${matchId}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    const response = await apiClient.get("", {
      params: {
        action: "get_lineups",
        match_id: matchId,
      },
    })

    // API yanıtını kontrol et
    if (!response.data || response.data === "No lineups found" || response.data.error) {
      console.log("Kadro verisi bulunamadı")
      return null
    }

    // Önbelleğe al
    cacheService.set(cacheKey, response.data, 15 * 1000) // 15 saniye önbellek
    return response.data
  } catch (error) {
    console.error("Kadro verisi çekilirken hata:", error)
    throw error
  }
}

// H2H maçları çek
export async function getHeadToHead(team1Id: string, team2Id: string) {
  try {
    const cacheKey = `h2h_${team1Id}_${team2Id}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    const response = await apiClient.get("", {
      params: {
        action: "get_H2H",
        firstTeamId: team1Id,
        secondTeamId: team2Id,
      },
    })

    // API yanıtını kontrol et
    if (
      !response.data ||
      !response.data.firstTeam_VS_secondTeam ||
      response.data.firstTeam_VS_secondTeam.length === 0
    ) {
      console.log("H2H verisi bulunamadı")
      return { matches: [] }
    }

    // Veriyi işle
    const h2hMatches = response.data.firstTeam_VS_secondTeam.map((match) => ({
      id: match.match_id,
      homeTeam: {
        id: match.match_hometeam_id,
        name: match.match_hometeam_name,
      },
      awayTeam: {
        id: match.match_awayteam_id,
        name: match.match_awayteam_name,
      },
      score: {
        fullTime: {
          home: Number.parseInt(match.match_hometeam_score) || 0,
          away: Number.parseInt(match.match_awayteam_score) || 0,
        },
      },
      utcDate: match.match_date,
      status: match.match_status,
    }))

    const result = { matches: h2hMatches }

    // Önbelleğe al
    cacheService.set(cacheKey, result, 30 * 60 * 1000) // 30 dakika önbellek
    return result
  } catch (error) {
    console.error("H2H verisi çekilirken hata:", error)
    throw error
  }
}

// Yıldız oyuncuları çek
export async function getStarPlayers(teamId: string) {
  try {
    const cacheKey = `star_players_${teamId}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    // Önce takım oyuncularını çek
    const response = await apiClient.get("", {
      params: {
        action: "get_teams",
        team_id: teamId,
      },
    })

    // API yanıtını kontrol et
    if (!response.data || (Array.isArray(response.data) && response.data.length === 0)) {
      console.log("Takım verisi bulunamadı")
      return null
    }

    // Veriyi işle
    let players = []

    if (Array.isArray(response.data) && response.data.length > 0) {
      // Oyuncuları çıkar
      if (response.data[0].players && Array.isArray(response.data[0].players)) {
        players = response.data[0].players.map((player) => ({
          id: player.player_id || `player-${Math.random().toString(36).substr(2, 9)}`,
          name: player.player_name,
          position: mapPosition(player.player_type),
          rating: Number.parseFloat(player.player_rating) || 6 + Math.random() * 4,
          goals: Number.parseInt(player.player_goals) || 0,
          assists: Number.parseInt(player.player_assists) || 0,
          matches: Number.parseInt(player.player_match_played) || 0,
        }))

        // Oyuncuları sırala (gol, asist, puan)
        players.sort((a, b) => {
          if (a.goals !== b.goals) return b.goals - a.goals
          if (a.assists !== b.assists) return b.assists - a.assists
          return b.rating - a.rating
        })

        // En iyi 5 oyuncuyu al
        players = players.slice(0, 5)
      }
    }

    // Oyuncu yoksa null döndür
    if (players.length === 0) {
      console.log("İşlenebilir oyuncu verisi bulunamadı")
      return null
    }

    // Önbelleğe al
    cacheService.set(cacheKey, players, 30 * 60 * 1000) // 30 dakika önbellek
    return players
  } catch (error) {
    console.error("Yıldız oyuncular çekilirken hata:", error)
    throw error
  }
}

// Pozisyon tipini dönüştür
function mapPosition(type: string): string {
  if (!type) return "Unknown"

  type = type.toLowerCase()

  if (type.includes("goalkeeper") || type.includes("kaleci")) return "Goalkeeper"
  if (type.includes("defender") || type.includes("defans")) return "Defender"
  if (type.includes("midfielder") || type.includes("orta saha")) return "Midfielder"
  if (type.includes("forward") || type.includes("forvet")) return "Attacker"

  return "Unknown"
}

// Takım formunu çekmek için fonksiyon
export async function getTeamForm(teamId: string) {
  try {
    const cacheKey = `team_form_${teamId}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    // Son 10 maçı çek
    const lastMatches = await getTeamLastMatches(teamId, 10)

    if (!Array.isArray(lastMatches) || lastMatches.length === 0) {
      console.log("Takım form verisi bulunamadı")
      return []
    }

    // Form hesapla (W, D, L)
    const form = lastMatches.map((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score || "0")
      const awayScore = Number.parseInt(match.match_awayteam_score || "0")

      if (isHome) {
        if (homeScore > awayScore) return "W"
        if (homeScore < awayScore) return "L"
        return "D"
      } else {
        if (homeScore < awayScore) return "W"
        if (homeScore > awayScore) return "L"
        return "D"
      }
    })

    // 30 dakika için önbelleğe al
    cacheService.set(cacheKey, form, 30 * 60 * 1000)
    return form
  } catch (error) {
    console.error("Takım formu hesaplanırken hata:", error)
    throw error
  }
}

// Takımın son maçlarını çek
export async function getTeamLastMatches(teamId: string, limit = 5) {
  try {
    const cacheKey = `team_last_matches_${teamId}_${limit}`
    const cachedData = cacheService.get(cacheKey)

    if (cachedData) {
      return cachedData
    }

    const response = await apiClient.get("", {
      params: {
        action: "get_events",
        team_id: teamId,
        from: "2023-01-01", // Yılın başından itibaren
        to: new Date().toISOString().split("T")[0], // Bugün
      },
    })

    // API yanıtını kontrol et
    if (!response.data || (Array.isArray(response.data) && response.data.length === 0)) {
      console.log("Takımın son maçları bulunamadı")
      return []
    }

    // Sadece son X maçı almak için işle
    let matches = Array.isArray(response.data) ? response.data : []

    // Tarihe göre sırala (en yeni önce)
    matches.sort((a, b) => {
      const dateA = new Date(`${a.match_date} ${a.match_time}`).getTime()
      const dateB = new Date(`${b.match_date} ${b.match_time}`).getTime()
      return dateB - dateA
    })

    // Sadece son 'limit' maçı al
    matches = matches.slice(0, limit)

    // 15 dakika için önbelleğe al
    cacheService.set(cacheKey, matches, 15 * 60 * 1000)
    return matches
  } catch (error) {
    console.error("Takımın son maçları çekilirken hata:", error)
    throw error
  }
}

// Ülkeleri çek
export async function getCountries() {
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_countries",
      },
    }),
    "countries",
    24 * 60 * 60 * 1000, // 24 saat önbellek
  )
}

// Ligleri çek
export async function getLeagues(countryId?: string) {
  const cacheKey = `leagues_${countryId || "all"}`
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_leagues",
        country_id: countryId,
      },
    }),
    cacheKey,
    24 * 60 * 60 * 1000, // 24 saat önbellek
  )
}

// Tüm ligleri çek
export async function getAllLeagues() {
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_leagues",
      },
    }),
    "all_leagues",
    24 * 60 * 60 * 1000, // 24 saat önbellek
  )
}

// Yaklaşan maçları çek
export async function getUpcomingMatches(from: string, to: string) {
  const cacheKey = `upcoming_matches_${from}_${to}`
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_events",
        from,
        to,
      },
    }),
    cacheKey,
    5 * 60 * 1000, // 5 dakika önbellek
  )
}

// Lig sıralamasını çek
export async function getStandings(leagueId: string) {
  const cacheKey = `standings_${leagueId}`
  return handleApiResponse(
    apiClient.get("", {
      params: {
        action: "get_standings",
        league_id: leagueId,
      },
    }),
    cacheKey,
    6 * 60 * 60 * 1000, // 6 saat önbellek
  )
}
