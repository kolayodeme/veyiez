import axios from "axios"
import { cacheService } from "./cache-service"

// Use the provided API key and base URL
const API_KEY = process.env.API_KEY || "683285e9509756c7701996a447e238940bd3bc11b26afb6e4de24994ad49ba22"
const API_BASE_URL = process.env.API_BASE_URL || "https://apiv3.apifootball.com"

// Create axios instance with retry logic
const api = axios.create({
  baseURL: API_BASE_URL,
  params: {
    APIkey: API_KEY,
  },
})

// Add retry logic
api.interceptors.response.use(undefined, async (error) => {
  const { config, response } = error

  // Only retry on network errors or 5xx errors
  if (!response || (response && response.status >= 500)) {
    config._retryCount = config._retryCount || 0

    if (config._retryCount < 3) {
      config._retryCount += 1

      // Exponential backoff
      const delay = 1000 * Math.pow(2, config._retryCount)
      await new Promise((resolve) => setTimeout(resolve, delay))

      return api(config)
    }
  }

  return Promise.reject(error)
})

// API functions with caching
export async function getLiveMatches() {
  const cacheKey = "live_matches"
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_events",
        match_live: "1",
      },
    })

    // Cache for a shorter period (15 seconds) since it's live data
    cacheService.set(cacheKey, response.data, 15 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching live matches:", error)
    throw error
  }
}

export async function getMatchDetails(matchId: string) {
  const cacheKey = `match_details_${matchId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_events",
        match_id: matchId,
      },
    })

    // Cache for 15 seconds for live matches
    cacheService.set(cacheKey, response.data, 15 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching match details:", error)
    throw error
  }
}

export async function getMatchStatistics(matchId: string) {
  const cacheKey = `match_statistics_${matchId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_statistics",
        match_id: matchId,
      },
    })

    // Cache for 15 seconds for live matches
    cacheService.set(cacheKey, response.data, 15 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching match statistics:", error)
    throw error
  }
}

export async function getMatchLineups(matchId: string) {
  const cacheKey = `match_lineups_${matchId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_lineups",
        match_id: matchId,
      },
    })

    // Cache for 15 seconds for live matches
    cacheService.set(cacheKey, response.data, 15 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching match lineups:", error)
    throw error
  }
}

export async function getUpcomingMatches(from: string, to: string) {
  const cacheKey = `upcoming_matches_${from}_${to}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_events",
        from,
        to,
      },
    })

    // Cache for 5 minutes since upcoming matches don't change frequently
    cacheService.set(cacheKey, response.data, 5 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching upcoming matches:", error)
    throw error
  }
}

export async function getTeamStatistics(teamId: string) {
  const cacheKey = `team_stats_${teamId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_statistics",
        team_id: teamId,
      },
    })

    // Cache for 10 minutes since team stats don't change frequently
    cacheService.set(cacheKey, response.data, 10 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching team statistics:", error)
    throw error
  }
}

export async function getTeamPlayers(teamId: string) {
  const cacheKey = `team_players_${teamId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_teams",
        team_id: teamId,
      },
    })

    // Cache for 1 hour since team players don't change frequently
    cacheService.set(cacheKey, response.data, 60 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching team players:", error)
    throw error
  }
}

export async function getH2HMatches(firstTeamId: string, secondTeamId: string) {
  const cacheKey = `h2h_${firstTeamId}_${secondTeamId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_H2H",
        firstTeamId,
        secondTeamId,
      },
    })

    // Cache for 30 minutes since H2H data doesn't change frequently
    cacheService.set(cacheKey, response.data, 30 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching H2H matches:", error)
    throw error
  }
}

export async function getTeamLastMatches(teamId: string, limit = 5) {
  const cacheKey = `team_last_matches_${teamId}_${limit}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_events",
        team_id: teamId,
        from: "2023-01-01", // Get matches from the beginning of the year
        to: new Date().toISOString().split("T")[0], // Today
      },
    })

    // Process to get only the last X matches
    let matches = Array.isArray(response.data) ? response.data : []

    // Sort by date (most recent first)
    matches.sort((a, b) => {
      const dateA = new Date(`${a.match_date} ${a.match_time}`).getTime()
      const dateB = new Date(`${b.match_date} ${b.match_time}`).getTime()
      return dateB - dateA
    })

    // Take only the last 'limit' matches
    matches = matches.slice(0, limit)

    // Cache for 15 minutes
    cacheService.set(cacheKey, matches, 15 * 60 * 1000)
    return matches
  } catch (error) {
    console.error("Error fetching team last matches:", error)
    throw error
  }
}

export async function getLeagues(countryId?: string) {
  const cacheKey = `leagues_${countryId || "all"}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_leagues",
        country_id: countryId,
      },
    })

    // Cache for 1 day since leagues don't change frequently
    cacheService.set(cacheKey, response.data, 24 * 60 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching leagues:", error)
    throw error
  }
}

export async function getCountries() {
  const cacheKey = "countries"
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_countries",
      },
    })

    // Cache for 1 day since countries don't change
    cacheService.set(cacheKey, response.data, 24 * 60 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching countries:", error)
    throw error
  }
}

export async function getAllLeagues() {
  const cacheKey = "all_leagues"
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_leagues",
      },
    })

    // Cache for 1 day since leagues don't change frequently
    cacheService.set(cacheKey, response.data, 24 * 60 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching all leagues:", error)
    throw error
  }
}

export async function getStandings(leagueId: string) {
  const cacheKey = `standings_${leagueId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_standings",
        league_id: leagueId,
      },
    })

    // Cache for 6 hours since standings change after matches
    cacheService.set(cacheKey, response.data, 6 * 60 * 60 * 1000)
    return response.data
  } catch (error) {
    console.error("Error fetching standings:", error)
    throw error
  }
}

// Enhanced API functions for betting prediction app

// Canlı maç istatistiklerini çekmek için düzeltilmiş fonksiyon
export async function getLiveMatchStatistics(matchId: string) {
  const cacheKey = `live_match_statistics_${matchId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_statistics",
        match_id: matchId,
      },
    })

    // Veri yapısını kontrol et ve düzenle
    let processedData = response.data

    // API'den gelen veriyi doğru formatta olduğundan emin ol
    if (Array.isArray(processedData) && processedData.length > 0) {
      // Veri zaten doğru formatta
    } else if (processedData && typeof processedData === "object") {
      // Veriyi dizi formatına dönüştür
      processedData = [processedData]
    } else {
      // Veri boş veya geçersiz ise boş dizi döndür
      processedData = []
    }

    // Kısa süre için önbelleğe al (15 saniye) çünkü canlı veri
    cacheService.set(cacheKey, processedData, 15 * 1000)
    return processedData
  } catch (error) {
    console.error("Error fetching live match statistics:", error)
    throw error
  }
}

// Canlı maç kadrosunu çekmek için düzeltilmiş fonksiyon
export async function getLiveMatchSquad(matchId: string) {
  const cacheKey = `live_match_squad_${matchId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    const response = await api.get("", {
      params: {
        action: "get_lineups",
        match_id: matchId,
      },
    })

    // Veri yapısını kontrol et
    let processedData = response.data

    // API'den gelen veriyi doğru formatta olduğundan emin ol
    if (!processedData || typeof processedData !== "object") {
      processedData = { lineup_home: null, lineup_away: null }
    }

    // Kısa süre için önbelleğe al (15 saniye) çünkü canlı veri
    cacheService.set(cacheKey, processedData, 15 * 1000)
    return processedData
  } catch (error) {
    console.error("Error fetching live match squad:", error)
    throw error
  }
}

// Yıldız oyuncuları çekmek için düzeltilmiş fonksiyon
export async function getStarPlayers(teamId: string) {
  const cacheKey = `star_players_${teamId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    // Önce takım oyuncularını çek
    const response = await api.get("", {
      params: {
        action: "get_teams",
        team_id: teamId,
      },
    })

    let players = []

    // API'den gelen veriyi kontrol et ve oyuncuları çıkar
    if (Array.isArray(response.data) && response.data.length > 0 && response.data[0].players) {
      players = response.data[0].players
    } else if (response.data && response.data.players) {
      players = response.data.players
    }

    // Oyuncuları istatistiklerine göre sırala (gol, asist, vb.)
    players.sort((a, b) => {
      // Gol sayısına göre sırala
      const aGoals = Number.parseInt(a.player_goals || "0")
      const bGoals = Number.parseInt(b.player_goals || "0")

      if (aGoals !== bGoals) return bGoals - aGoals

      // Asist sayısına göre sırala
      const aAssists = Number.parseInt(a.player_assists || "0")
      const bAssists = Number.parseInt(b.player_assists || "0")

      if (aAssists !== bAssists) return bAssists - aAssists

      // Puana göre sırala
      const aRating = Number.parseFloat(a.player_rating || "0")
      const bRating = Number.parseFloat(b.player_rating || "0")

      return bRating - aRating
    })

    // En iyi oyuncuları al (ilk 5)
    const starPlayers = players.slice(0, 5)

    // 5 dakika için önbelleğe al
    cacheService.set(cacheKey, starPlayers, 5 * 60 * 1000)
    return starPlayers
  } catch (error) {
    console.error("Error fetching star players:", error)
    throw error
  }
}

// Takım formunu çekmek için yeni fonksiyon
export async function getTeamForm(teamId: string) {
  const cacheKey = `team_form_${teamId}`
  const cachedData = cacheService.get(cacheKey)

  if (cachedData) {
    return cachedData
  }

  try {
    // Son 10 maçı çek
    const lastMatches = await getTeamLastMatches(teamId, 10)

    // Form hesapla (W, D, L)
    const form = lastMatches.map((match) => {
      const isHome = match.match_hometeam_id === teamId
      const homeScore = Number.parseInt(match.match_hometeam_score || "0")
      const awayScore = Number.parseInt(match.match_awayteam_score || "0")

      if (isHome) {
        if (homeScore > awayScore) return "W"
        if (homeScore < awayScore) return "L"
        return "D"
      } else {
        if (homeScore < awayScore) return "W"
        if (homeScore > awayScore) return "L"
        return "D"
      }
    })

    // 30 dakika için önbelleğe al
    cacheService.set(cacheKey, form, 30 * 60 * 1000)
    return form
  } catch (error) {
    console.error("Error calculating team form:", error)
    throw error
  }
}
